# Word–Quarto toolkit

Release 1.0.1 · Windows · Python and batch launchers

For the architecture, conversion flow and an explanation of every file and function, see [DESIGN.md](DESIGN.md). This release adds that guide and code comments; conversion behavior is unchanged from 1.0.0.

Convert a Word `.docx` into editable Quarto Markdown (`.qmd`), then build Word documents using the source document's styles or standalone HTML files for review. Word exports include visible data-table borders and native `SEQ Figure`, `SEQ Table` and linked `REF` fields.

This release contains only the reusable tool. Projects, sample documents, generated output, development tests and manual-specific filters are excluded. Copy the **whole toolkit folder** to another computer. No PowerShell scripts or execution-policy changes are required.

## 1. Set up

Use your company's approved installations of:

- **Python 3.10 or later.**
- **Quarto**, including its bundled Pandoc. This release was tested with Quarto 1.10.18 and Pandoc 3.10.
- **Pillow 12.3 or later in the 12.x series**, only when HTML review needs WMF/EMF picture previews on Windows. PNG/JPEG pictures and Word conversion do not require Pillow.

Microsoft Word is not required for conversion. Use Word to check pagination, update fields and insert lists of figures and tables.

Extract the ZIP into a writable location. Open **Command Prompt** (`cmd`) and change to the extracted toolkit folder. For example:

```bat
cd /d "C:\Tools\quarto-docx-toolkit"
py -3 --version
quarto --version
```

If your Python command is `python`, substitute it for `py -3`. The batch launchers try `py -3` first, then `python`. To select a specific approved Python installation for this Command Prompt session:

```bat
set "TOOLKIT_PYTHON=C:\Approved Python\python.exe"
```

If WMF/EMF previews are needed, install the optional dependency into the same Python environment used by the launcher:

```bat
scripts\run-python.bat -m pip install -r requirements.txt
```

If downloads are restricted, have IT supply the package from an approved source. The ZIP does not bundle Python, Quarto or Pillow.

## 2. Convert DOCX to QMD

Run this from the toolkit folder, replacing the input path:

```bat
scripts\import-docx.bat "C:\Documents\Report.docx" --project-name report
```

The importer creates:

```text
projects/
  report/
    report.qmd       Editable content
    original.docx    Unchanged copy of the input
    reference.docx   Word style and page-setting reference
    _quarto.yml      Project configuration
    review.css       HTML appearance
    assets/          Extracted pictures, when present
```

The input document is unchanged. The reference copies its styles and supplies figure/table caption styles from `Caption` when needed. Recognized English figure/table captions become Quarto caption markup. Redundant `Body Text` wrappers are omitted; special style wrappers are retained.

Import will **refuse to overwrite an existing project**. Choose a different project name to import a revised original without replacing your edited QMD. Project names must start with a letter or number and use only letters, numbers, hyphens, underscores or periods; avoid `..`, trailing periods, Windows reserved names, `original` and `reference`.

## 3. Edit the QMD

Open `projects\report\report.qmd` in a text editor. Add, edit or delete sentences, sections, tables and pictures. Keep the entire project folder together and keep backups of your edits.

### Text and sections

```markdown
# New section

A paragraph with **bold** and *italic* text.

## Subsection

- First item
- Second item
```

Separate paragraphs and blocks with blank lines. Ordinary paragraphs do not need `::: {custom-style="Body Text"}` wrappers. Keep matching `:::` markers around imported special styles and figure blocks. To reuse a special paragraph style that exists in the reference:

```markdown
::: {custom-style="Body Text Indent"}
This paragraph uses the named Word style.
:::
```

### Pictures and figure captions

Copy a new picture into the project's `assets` folder, then insert:

```markdown
![Measurement setup.](assets/setup.png){#fig-setup width="5in"}

See @fig-setup for the setup.
```

Use unique identifiers starting with `fig-`. Write only the caption text; Quarto adds the label and number. For several pictures sharing one caption, use a figure block with one picture per paragraph:

```markdown
::: {#fig-comparison}
![](assets/before.png)

![](assets/after.png)

Before and after the change.
:::
```

### Tables and table captions

```markdown
| Material | Density |
|:---------|--------:|
| Concrete | 2350    |
| Mortar   | 2100    |

: Material densities. {#tbl-density}

See @tbl-density for the values.
```

Use unique identifiers starting with `tbl-`. Keep a blank line before the caption. Data tables use an explicit table style from the reference when available; otherwise they receive thin black cell borders. Explicitly selected borderless styles remain borderless. Figure/caption layout tables stay borderless.

When deleting a figure or table, remove or redirect its references too. Replace literal prose such as “see Figure 1” with `@fig-setup` if the number must update after edits. Do not use `.caption` or `.captions` as plain caption text.

## 4. Build Word

Close any previous export in Word, then run:

```bat
scripts\build.bat --project "projects\report" --format docx
```

Open `projects\report\output\report.docx`. Each build replaces this generated file. Keep QMD as the source of content; edits made only to the exported Word document will be replaced on the next build. To change reusable formatting, edit the **styles** in `reference.docx` and rebuild.

**Always use `build.bat` or `toolkit.py build` for Word export.** Running `quarto render` directly skips the Python steps that finish table styles, create native Word fields and verify picture counts.

### Update captions and create lists in Word

1. In the generated document, press **Ctrl+A**, then **F9**. Repeat **F9** to refresh references that precede their targets. Some keyboards require **Fn+F9**.
2. Place the cursor where the list of figures should appear. Choose **References > Insert Table of Figures**, select **Figure** as the caption label and click **OK**.
3. At a different location, repeat **Insert Table of Figures** with the **Table** caption label to create the list of tables.
4. After further Word edits, update the fields and each list using **Update entire table**.

Caption numbers are genuine `{ SEQ Figure \* ARABIC }` and `{ SEQ Table \* ARABIC }` fields. Linked QMD references receive `REF` fields for their numbers. Keep the default Quarto `ref-hyperlink: true` setting for this feature. Manually typed numbers and descriptive links remain literal.

Lists inserted only in Word are also replaced on the next QMD build. Add them after the final export or save a separate Word working copy.

## 5. Build HTML for review

```bat
scripts\build.bat --project "projects\report" --format html
```

Open `projects\report\output\report.html` in a browser. Images, styles and scripts are embedded, so you can share that one HTML file. HTML is for reviewing content and navigation; it does not reproduce Word pagination.

WMF/EMF pictures under `assets` receive `*-review.png` previews automatically when Pillow is installed. Original vector pictures remain available for Word. No separate image-preparation command is needed.

## 6. Move an existing project to this release

For a project created by the generic importer:

1. Copy its **entire project folder** into this toolkit's `projects` folder (create `projects` if necessary). Keep the edited QMD, `reference.docx`, `_quarto.yml`, `review.css` and `assets` together.
2. If it uses an older configuration, set its `_quarto.yml` filter list to the following, keeping the other settings:

   ```yaml
   filters:
     - ../../scripts/html-images.lua
     - ../../scripts/table-borders.lua
     - quarto
     - ../../scripts/docx-captions.lua
   ```

3. Build with `--project "projects\YOUR-PROJECT"`. Do not re-import over an edited QMD.

The old prepared root manual used `manual-style.lua` and `docx-layout.lua` for document-specific formatting. Those filters are not part of this general release. Keep that prepared manual in its existing toolkit; to start a new generic project from its source DOCX, use the import command above.

## Options and troubleshooting

- **Python-only use:** if batch files are restricted, run the same commands directly:

  ```bat
  py -3 scripts\toolkit.py import "C:\Documents\Report.docx" --project-name report
  py -3 scripts\toolkit.py build --project "projects\report" --format docx
  py -3 scripts\toolkit.py build --project "projects\report" --format html
  ```

- **Quarto not found:** append `--quarto "C:\Approved Quarto\bin\quarto.exe"` to the import or build command. Keep Quarto's bundled `tools` directory intact.
- **More than one QMD:** append `--input-file report.qmd` to build the chosen file. The QMD must be directly inside its project folder.
- **Project paths:** relative `--project` paths are resolved from the toolkit folder. Input DOCX paths are resolved from the current Command Prompt directory. Quote paths containing spaces.
- **No project configuration:** always pass `--project`; the clean release itself is not a document project.
- **Missing picture:** correct its QMD path and copy the image into the project. If an older import omitted it, import the original DOCX under a new project name and copy the missing picture/block into your edited project.
- **Literal `.captions`:** replace the malformed markup with the figure/table caption syntax in section 3. The build rejects stray caption tokens rather than silently producing broken captions.
- **Output in use:** close the generated Word document before rebuilding. Do not put a DOCX with the same basename as the QMD beside that QMD; Quarto uses that location temporarily. Keep the source as `original.docx` and outputs under `output`.
- **Build failure:** correct the reported error and rebuild successfully before distributing the output. A failed build may leave an older or partial export in `output`.

### Scope and limits

The toolkit reuses named Word styles and page settings. It is not a lossless reconstruction of arbitrary Word layout: floating objects, text boxes, complex merged tables, manual spacing and pagination can need review after import. HTML uses the included CSS rather than Word's page layout.

Native caption fields support standard English figure/table labels with continuous Arabic numbering starting at 1 independently for figures and tables. Chapter numbering, Roman/letter schemes and numbered subfigures are not supported. Caption and linked-reference field conversion applies to the document body, including Quarto layout tables. Review captions that the DOCX importer did not recognize and convert them to the syntax in section 3.

## Files included

| File(s) | Purpose |
|---|---|
| `scripts/import-docx.bat`, `scripts/build.bat` | Command Prompt entry points |
| `scripts/run-python.bat` | Select Python 3.10+ or `TOOLKIT_PYTHON` |
| `scripts/toolkit.py` | Import, build and validation commands |
| `scripts/docx_import.py` | Preserve pictures and prepare caption styles |
| `scripts/docx_tables.py` | Finish data-table and layout-table styles |
| `scripts/docx_fields.py` | Create native caption and cross-reference fields |
| `scripts/import-captions.lua`, `scripts/clean-body-text.lua` | Import captions and simplify ordinary paragraphs |
| `scripts/body-text.lua`, `scripts/docx-captions.lua` | Apply Word paragraph/caption styles on export |
| `scripts/table-borders.lua` | Identify data tables before Quarto creates layout tables |
| `scripts/check-document.lua` | Check image resources during rendering |
| `scripts/html-images.lua` | Use PNG previews of WMF/EMF images in HTML |
| `styles/review.css` | Initial HTML stylesheet copied into each project |
| `requirements.txt` | Optional Pillow dependency |
| `README.md` | These instructions |
| `DESIGN.md` | Detailed design, file/function guide and implementation limits |

Keep all release files together. The importer creates project configuration and reference documents per input, so no sample project or reference DOCX is required in the release.
