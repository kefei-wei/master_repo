@echo off
REM Launch the import subcommand using scripts beside this batch file.
REM The dp0 expansion means this batch file's drive and directory.
REM Forward all caller arguments and return Python's exit status unchanged.
call "%~dp0run-python.bat" "%~dp0toolkit.py" import %*
exit /b %errorlevel%
