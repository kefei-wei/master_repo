-- Ordinary paragraphs already use the reference document's body style.
-- Remove only style-only Body Text divs, without discarding other attributes.
return {{
  -- Visit a style wrapper before its children, allowing special-style subtrees
  -- to opt out of cleanup before any nested Body Text reset is removed.
  traverse = 'topdown',
  Div = function(div)
    local style = div.attributes['custom-style']
    if not style then return nil end

    -- Within another explicit style, Body Text may reset inherited formatting.
    -- Leave that entire subtree intact, including footnotes and table cells.
    if style ~= 'Body Text' then return div, false end
    -- IDs, classes and extra attributes can carry anchors or other semantics;
    -- unwrap only a container whose sole purpose is selecting Body Text.
    if div.identifier ~= '' or #div.classes > 0 then return nil end
    for key, _ in pairs(div.attributes) do
      if key ~= 'custom-style' then return nil end
    end
    -- Replace the wrapper with its original blocks, preserving their order.
    return div.content
  end
}}
