-- Rendering-time resource check added by toolkit.py as a command-line filter.
-- It runs after Quarto's core pass; check_qmd also validates paths before render.
-- Pandoc calls Image once for every image node it encounters in the document.
function Image(image)
  local src = image.src
  -- Remote and embedded images are handled by the renderer, not local io.open.
  if src:match('^https?://') or src:match('^data:') then return nil end
  -- Decode URL escapes such as %20 so paths containing spaces can be opened.
  local decoded = src:gsub('%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
  local file = io.open(decoded, 'rb')
  if not file then
    error('Missing image file: ' .. src .. '. Keep assets with the QMD and check the image path.')
  end
  -- A successful open is sufficient. Returning no replacement leaves the node
  -- unchanged, and closing the handle avoids locking image files on Windows.
  file:close()
end
