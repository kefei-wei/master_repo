-- Keep ordinary body paragraphs consistent, including after a heading.
-- Pandoc otherwise selects FirstParagraph, which may be missing or different
-- in an imported reference. Apply this only during Word export, after Quarto.
if not FORMAT:match('docx') then return {} end

return {{Pandoc = function(doc)
  -- Inspect only top-level blocks. Recursing into explicit style containers
  -- would override the special formatting the importer deliberately retained.
  for index, block in ipairs(doc.blocks) do
    if block.t == 'Para' then
      local ordinary = true
      -- A paragraph containing a picture or raw Word markup is not ordinary
      -- prose and may already be part of Quarto's figure/caption machinery.
      block:walk({
        Image = function() ordinary = false end,
        RawInline = function() ordinary = false end
      })
      if ordinary then
        -- Apply the style in the export tree only; do not clutter the saved QMD
        -- with wrappers that can be recreated automatically on every build.
        doc.blocks[index] = pandoc.Div({block},
          pandoc.Attr('', {}, {['custom-style'] = 'Body Text'}))
      end
    end
  end
  -- Explicit style divs, headings, lists, tables, figures and notes are intact.
  return doc
end}}
