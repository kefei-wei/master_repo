"""Portable DOCX / Quarto commands. No PowerShell or Microsoft Word required."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from urllib.parse import unquote, urlparse
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from docx_import import copy_caption_styles, split_picture_runs
from docx_tables import finish_tables
from docx_fields import finish_fields

# Resolve resources from this file, not the caller's current directory, so the
# complete toolkit can be moved or renamed without changing its internal paths.
BUNDLE = Path(__file__).resolve().parent.parent
# Written into projects/<name>/_quarto.yml on import. The two-level filter paths
# depend on that folder structure. Mark data tables BEFORE Quarto builds its
# layout tables; fix caption paragraph styles AFTER Quarto creates captions.
# Disable code execution because imported manuals are treated as static content.
CONFIG = """project:
  type: default
  output-dir: output
format:
  docx:
    reference-doc: reference.docx
    toc: false
    number-sections: false
  html:
    embed-resources: true
    toc: true
    css: review.css
filters:
  - ../../scripts/html-images.lua
  - ../../scripts/table-borders.lua
  - quarto
  - ../../scripts/docx-captions.lua
execute:
  enabled: false
"""


# Prefer the user's explicit executable, then common Windows install locations,
# then PATH. Return a Path so callers can also find Quarto's bundled Pandoc.
def find_quarto(explicit: str | None) -> Path:
    if explicit:
        candidate = Path(explicit).expanduser().resolve()
        if not candidate.is_file():
            raise ValueError(f"Quarto executable not found: {candidate}")
        return candidate
    candidates = []
    for variable, suffix in [("ProgramFiles", "Quarto/bin/quarto.exe"),
                             ("LOCALAPPDATA", "Programs/Quarto/bin/quarto.exe")]:
        if os.environ.get(variable):
            candidates.append(Path(os.environ[variable]) / suffix)
    located = shutil.which("quarto")
    if located:
        path = Path(located)
        candidates.extend([path.with_suffix(".exe"), path])
    for path in candidates:
        if path.is_file():
            return path.resolve()
    raise ValueError("Quarto was not found. Install Quarto or use --quarto PATH.")


# Unlike input DOCX paths, relative project paths are anchored to the toolkit.
def project_path(value: str) -> Path:
    path = Path(value).expanduser()
    return (path if path.is_absolute() else BUNDLE / path).resolve()


# Create a new editable project. Never reuse an existing project directory:
# importing again must not overwrite the user's edited QMD or reference styles.
def import_docx(args: argparse.Namespace) -> None:
    source = Path(args.input_docx).expanduser().resolve()
    if source.suffix.lower() != ".docx" or not source.is_file():
        raise ValueError(f"Input must be an existing .docx file: {source}")
    # Sanitize the default name and reject path traversal, Windows device names,
    # and names that would collide with the source/reference DOCX copies.
    name = args.project_name or re.sub(r"[^A-Za-z0-9._-]", "_", source.stem)
    if (not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", name) or ".." in name
            or name.endswith(".") or name.lower() in {"original", "reference"}
            or re.fullmatch(r"(?i)(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\..*)?", name)):
        raise ValueError("Use --project-name with a name starting with a letter or number; "
                         "use only letters, numbers, periods, underscores and hyphens. "
                         "Avoid '..', trailing periods, Windows reserved names, original and reference.")
    target = BUNDLE / "projects" / name
    if target.exists():
        raise ValueError(f"Project already exists: {target}. Choose another --project-name to preserve edits.")
    quarto = find_quarto(args.quarto)
    pandoc = quarto.parent / "tools" / ("pandoc.exe" if os.name == "nt" else "pandoc")
    if not pandoc.is_file():
        raise ValueError(f"Cannot find Pandoc bundled with Quarto: {pandoc}")
    target.mkdir(parents=True)
    # Distinct source/template names avoid Quarto's temporary output filename.
    shutil.copy2(source, target / "original.docx")
    copy_caption_styles(source, target / "reference.docx")
    shutil.copy2(BUNDLE / "styles" / "review.css", target / "review.css")
    (target / "_quarto.yml").write_text(CONFIG, encoding="utf-8")
    # Word can store several pictures in one run; Pandoc silently drops all but
    # the first unless the run is split. Only the temporary copy is normalized.
    with tempfile.TemporaryDirectory(prefix="docx-import-") as temporary:
        normalized = Path(temporary) / "normalized.docx"
        changed = split_picture_runs(source, normalized)
        # docx+styles exposes named Word styles in the document tree. The Lua
        # filters convert captions and remove redundant Body Text wrappers.
        # Fenced divs/spans retain special styles; disabling simple/multiline
        # tables avoids Markdown table forms that are awkward to edit in QMD.
        # Run inside the project so extracted image paths stay portable.
        subprocess.run([str(pandoc), str(normalized), "-f", "docx+styles", "-t",
                        "markdown+fenced_divs+bracketed_spans-simple_tables-multiline_tables",
                        "--lua-filter", str(BUNDLE / "scripts" / "import-captions.lua"),
                        "--lua-filter", str(BUNDLE / "scripts" / "clean-body-text.lua"),
                        "--wrap=none", "--extract-media=assets", "-o", name + ".qmd"],
                       cwd=target, check=True)
    if changed:
        print(f"Preserved pictures by splitting {changed} multi-picture Word run(s).")
    print(f"Created {target}\nEdit {name}.qmd, then run:")
    print(f'scripts\\build.bat --project "projects/{name}" --format docx')


# Yield dictionaries from Pandoc's nested JSON tree, including nested lists.
# This lets preflight checks count actual syntax nodes rather than text patterns.
def walk_nodes(value):
    if isinstance(value, dict):
        yield value
        # Literal code is not image/caption markup.
        if value.get("t") not in {"Code", "CodeBlock"}:
            for child in value.values():
                yield from walk_nodes(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_nodes(child)


def check_qmd(source: Path, quarto: Path) -> tuple[int, int]:
    """Parse Markdown rather than guessing image syntax using regular expressions."""
    pandoc = quarto.parent / "tools" / ("pandoc.exe" if os.name == "nt" else "pandoc")
    parsed = subprocess.run([str(pandoc), source.name, "-f", "markdown", "-t", "json"],
                            cwd=source.parent, capture_output=True, text=True,
                            encoding="utf-8", check=True)
    nodes = list(walk_nodes(json.loads(parsed.stdout)))
    images = [node for node in nodes if node.get("t") == "Image"]
    missing = []
    for image in images:
        # Pandoc Image contents are [attributes, caption inlines, [URL, title]].
        src = image["c"][2][0]
        uri = urlparse(src)
        # Network/data URLs are left to the renderer; this is a local-file check.
        if uri.scheme in {"http", "https", "data"}:
            continue
        if not (source.parent / unquote(src)).is_file():
            missing.append(src)
    if missing:
        raise ValueError("Missing image file(s): " + ", ".join(sorted(set(missing)))
                         + ". Keep the project's assets folder with the QMD; use paths such as assets/media/image1.png.")
    # A standalone .caption/.captions token signals markup being rendered as
    # prose. Ignore literal code examples, which walk_nodes does not descend into.
    leftovers = [node["c"] for node in nodes if node.get("t") == "Str"
                 and re.fullmatch(r"\{?\.captions?\}?", node["c"], re.I)]
    if leftovers:
        raise ValueError("Caption markup is being read as plain text: " + ", ".join(set(leftovers))
                         + ". Use ![Caption](assets/image.png){#fig-label} for pictures and "
                         "a separate ': Caption {#tbl-label}' line for tables. See README recovery instructions.")
    print(f"Checked QMD: {len(images)} image reference(s); all local image files exist.", flush=True)
    tables = sum(node.get('t') == 'Table' for node in nodes)
    return len(images), tables


# Generate browser-compatible siblings for every WMF/EMF under assets. The
# originals remain untouched for Word; html-images.lua swaps paths only in HTML.
def prepare_images(project: Path) -> None:
    vectors = sorted(p for p in (project / "assets").rglob("*")
                     if p.is_file() and p.suffix.lower() in {".wmf", ".emf"})
    if not vectors:
        return
    if os.name != "nt":
        raise ValueError("WMF/EMF preview conversion requires Windows. Use PNG/JPEG images instead.")
    try:
        # Import lazily: Pillow is optional for all other conversion paths.
        import PIL
        from PIL import Image
    except ImportError as exc:
        raise ValueError("WMF/EMF previews require Pillow. Run: python -m pip install -r requirements.txt") from exc
    version = tuple(int(x) for x in PIL.__version__.split(".")[:2])
    if version < (12, 3):
        raise ValueError("WMF/EMF previews require Pillow 12.3 or later. Install requirements.txt.")
    for source in vectors:
        target = source.with_name(source.stem + "-review.png")
        with Image.open(source) as image:
            # Render the vector at higher resolution, bounded to a 2048px edge.
            scale = min(2.5, 2048 / max(image.size))
            dpi = image.info.get("dpi", 72)
            if not isinstance(dpi, tuple):
                dpi = (dpi, dpi)
            image.load(dpi=(dpi[0] * scale, dpi[1] * scale))
            image.convert("RGB").save(target, "PNG")
        print(f"Preview: {target}", flush=True)


def ensure_table_filter(project: Path) -> None:
    """Upgrade toolkit configs once, retaining a backup and all other settings.

    Quarto puts command-line Lua filters after its own filter, which is too late
    to distinguish real data tables from generated figure/caption wrappers.
    """
    path = project / '_quarto.yml'
    config = path.read_text(encoding='utf-8-sig')
    # Edit just the filter list as text, retaining unrelated YAML and comments.
    # A general YAML rewrite would add a dependency and could alter formatting.
    lines = config.splitlines(keepends=True)
    core = [i for i, line in enumerate(lines)
            if re.fullmatch(r"\s*-\s*['\"]?quarto['\"]?\s*(?:#.*)?", line.strip())]
    if len(core) != 1:
        raise ValueError('The project filter list must contain one explicit quarto entry. '
                         'Place scripts/table-borders.lua (relative to the project) immediately before it.')
    # Already-correct projects are left alone. Ambiguous or incorrectly ordered
    # entries are rejected so the user can repair the configuration explicitly.
    existing = [i for i, line in enumerate(lines) if re.match(r'\s*-\s*', line)
                and 'table-borders.lua' in line]
    if existing:
        if len(existing) != 1 or existing[0] > core[0]:
            raise ValueError('Place table-borders.lua once, before quarto in _quarto.yml.')
        return
    filter_path = BUNDLE / 'scripts' / 'table-borders.lua'
    try:
        relative = Path(os.path.relpath(filter_path, project)).as_posix()
    except ValueError:
        # Windows projects on a different drive cannot use a relative path.
        relative = filter_path.as_posix()
    indent = re.match(r'\s*', lines[core[0]]).group()
    lines.insert(core[0], indent + '- ' + json.dumps(relative) + '\n')
    backup = path.with_name('_quarto.yml.before-table-fix')
    if not backup.exists():
        shutil.copy2(path, backup)
    path.write_text(''.join(lines), encoding='utf-8')
    print(f'Enabled table styling in {path.name}; original configuration saved as {backup.name}.', flush=True)


# Orchestrate preflight -> render -> Word-only finishing -> verification.
# HTML uses the same QMD but skips all DOCX ZIP/XML post-processing.
def build(args: argparse.Namespace) -> None:
    project = project_path(args.project)
    if not (project / "_quarto.yml").is_file():
        raise ValueError(f"No _quarto.yml found in project: {project}")
    if args.input_file:
        source = (project / args.input_file).resolve()
    else:
        sources = list(project.glob("*.qmd"))
        if len(sources) != 1:
            raise ValueError("Project must contain exactly one QMD, or specify --input-file NAME.qmd.")
        source = sources[0].resolve()
    if source.parent != project or source.suffix.lower() != ".qmd" or not source.is_file():
        raise ValueError("The selected QMD must be a file directly inside the project folder.")
    # Quarto stages output beside the QMD before moving it into output/.
    staged_output = source.with_suffix("." + args.format)
    if staged_output.exists():
        raise ValueError(f"Move or rename {staged_output.name} before building: Quarto uses that "
                         "filename temporarily. Keep original Word files under a different name.")
    quarto = find_quarto(args.quarto)
    expected_images, expected_tables = check_qmd(source, quarto)
    if args.format == "html":
        prepare_images(project)
    else:
        ensure_table_filter(project)
    # Configuration controls the filters that straddle Quarto's core pass.
    # These additional command-line filters run afterward; warnings fail builds
    # instead of allowing potentially incomplete outputs to be reported as good.
    subprocess.run([str(quarto), "render", source.name, "--to", args.format,
                    "--fail-if-warnings", "--lua-filter",
                    str(BUNDLE / "scripts" / "check-document.lua"), "--lua-filter",
                    str(BUNDLE / "scripts" / "body-text.lua")], cwd=project, check=True)
    if args.format == "docx":
        output = project / "output" / (source.stem + ".docx")
        if output.is_file():
            # Render first: only the finished DOCX exposes the real Word tables
            # and caption runs that these standard-library helpers must edit.
            data_count, layout_count = finish_tables(output, expected_tables)
            print(f"Verified tables: {data_count} data table(s), {layout_count} borderless layout table(s).")
            figure_fields, table_fields, reference_fields = finish_fields(output)
            print(f"Word fields: {figure_fields} SEQ Figure, {table_fields} SEQ Table, "
                  f"{reference_fields} linked REF field(s).")
            # Count picture placements rather than ZIP media files: one image
            # may be reused several times. A count check detects loss, but does
            # not prove visual layout or that each picture is the intended one.
            with ZipFile(output) as package:
                actual = 0
                for member in ("word/document.xml", "word/footnotes.xml", "word/endnotes.xml"):
                    if member in package.namelist():
                        document = ET.fromstring(package.read(member))
                        actual += len(document.findall(".//{http://schemas.openxmlformats.org/drawingml/2006/main}blip"))
            if actual < expected_images:
                raise ValueError(f"Output image check failed: {expected_images} QMD images, {actual} Word pictures. "
                                 "The output was created but is incomplete; do not use it.")
            print(f"Verified Word output: {actual} picture placement(s).")
    print(f"Build finished. See {project / 'output'}")


# Shared entry point for batch launchers and direct Python use. argparse handles
# command syntax; expected conversion errors become a message and exit code 1.
def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    importer = commands.add_parser("import", help="Import another Word document into projects/.")
    importer.add_argument("input_docx", help="DOCX path, relative to your current directory or absolute.")
    importer.add_argument("--project-name")
    importer.add_argument("--quarto", help="Full path to the Quarto executable.")
    builder = commands.add_parser("build", help="Build Word or standalone HTML.")
    builder.add_argument("--project", default=".", help="Absolute path or path relative to toolkit folder.")
    builder.add_argument("--input-file", help="QMD filename inside the project.")
    builder.add_argument("--format", choices=["docx", "html"], default="docx")
    builder.add_argument("--quarto", help="Full path to the Quarto executable.")
    # Retain a direct preview-regeneration command for troubleshooting; normal
    # HTML builds call prepare_images automatically and need no extra launcher.
    images = commands.add_parser("images", help="Regenerate WMF/EMF PNG previews (also done by HTML build).")
    images.add_argument("--project", default=".")
    args = parser.parse_args()
    try:
        if args.command == "import":
            import_docx(args)
        elif args.command == "build":
            build(args)
        else:
            project = project_path(args.project)
            if not project.is_dir():
                raise ValueError(f"Project does not exist: {project}")
            prepare_images(project)
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
