-- Quarto currently emits raw ImageCaption properties for both float types.
-- Use native paragraph styles and prevent duplicate w:pPr elements in Word.
if not FORMAT:match('docx') then return {} end

-- Handle both paragraph node types because Quarto can emit either in a float.
local function caption(p)
  local found = false
  for _, inline in ipairs(p.content) do
    if inline.t == 'RawInline' and inline.format == 'openxml'
       and inline.text:find('ImageCaption', 1, true) then found = true end
  end
  -- Restrict the rewrite to Quarto's generated caption markup, not ordinary
  -- paragraphs that happen to mention figures or tables.
  if not found then return nil end
  local contents = p.content:filter(function(i)
    return not (i.t == 'RawInline' and i.format == 'openxml'
                and i.text:find('<w:pPr>', 1, true))
  end)
  -- The replacement custom-style Div makes Pandoc emit one paragraph-properties
  -- element. Standard English labels distinguish tables from figures here.
  -- Native SEQ fields are a later responsibility of docx_fields.py.
  local style = pandoc.utils.stringify(contents):match('^Table') and 'Table Caption' or 'Image Caption'
  return pandoc.Div({pandoc.Para(contents)}, pandoc.Attr('', {}, {['custom-style']=style}))
end

return {{Para=caption, Plain=caption}}
