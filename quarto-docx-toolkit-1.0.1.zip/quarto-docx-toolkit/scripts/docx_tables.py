"""Finish tagged data tables after Quarto has created the Word layout tables.

Uses only Python's standard library. The original QMD and reference are not
modified. Table identity comes from a filter marker, never from cell counts.
"""
import os
from pathlib import Path
from xml.dom import Node, minidom
from zipfile import ZipFile

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
# Shared protocol with table-borders.lua: an XML comment in the first table cell
# contains this prefix followed by the requested style name encoded as UTF-8 hex.
MARKER = 'toolkit-data-table:'
DATA_STYLE = 'ToolkitDataTable'
LAYOUT_STYLE = 'ToolkitLayoutTable'


# Return immediate WordprocessingML children only. Descendant searches could
# accidentally select properties belonging to a nested table or inner run.
def children(element, local):
    return [n for n in element.childNodes if n.nodeType == Node.ELEMENT_NODE
            and n.namespaceURI == W and n.localName == local]


# Construct a WordprocessingML element and namespace-qualified attributes.
# docx_fields.py reuses this helper and children() for its field XML.
def element(doc, tag, **attrs):
    el = doc.createElementNS(W, 'w:' + tag)
    for key, value in attrs.items():
        el.setAttributeNS(W, 'w:' + key, str(value))
    return el


# Ensure one table-style reference at the start of tblPr, retaining other table
# properties such as widths, alignment and any direct formatting.
def set_style(table, name):
    doc = table.ownerDocument
    properties = children(table, 'tblPr')
    if properties:
        properties = properties[0]
    else:
        properties = element(doc, 'tblPr')
        table.insertBefore(properties, table.firstChild)
    for old in children(properties, 'tblStyle'):
        properties.removeChild(old)
    properties.insertBefore(element(doc, 'tblStyle', val=name), properties.firstChild)


# Create a fallback style only when absent. Data tables need a grid; layout
# tables need explicit nil borders so figure/caption wrappers stay invisible.
def ensure_style(styles, name, bordered):
    # An existing user-customized toolkit style is kept.
    for style in styles.getElementsByTagNameNS(W, 'style'):
        if style.getAttributeNS(W, 'styleId') == name:
            if style.getAttributeNS(W, 'type') != 'table':
                raise ValueError(f'{name} exists as a non-table style in the reference.')
            return
    style = element(styles, 'style', type='table', styleId=name, customStyle='1')
    style.appendChild(element(styles, 'name', val='Toolkit Data Table' if bordered else 'Toolkit Layout Table'))
    style.appendChild(element(styles, 'basedOn', val='TableNormal'))
    properties = element(styles, 'tblPr')
    borders = element(styles, 'tblBorders')
    # Word measures border size in eighths of a point: sz=4 means 0.5 pt.
    # Define all four outer edges plus both internal grid directions.
    for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        attrs = dict(val='single', sz='4', color='000000', space='0') if bordered else dict(val='nil')
        borders.appendChild(element(styles, side, **attrs))
    properties.appendChild(borders)
    style.appendChild(properties)
    styles.documentElement.appendChild(style)


# Walk a snapshot of each node's children so callers may safely remove markers.
def comments(node):
    for child in list(node.childNodes):
        if child.nodeType == Node.COMMENT_NODE:
            yield child
        yield from comments(child)


def finish_tables(path: Path, expected_tables: int):
    """Restore data table styles and isolate Quarto's borderless layout tables."""
    path = Path(path)
    replacements = {}
    count = layout_count = 0
    with ZipFile(path) as source:
        styles = minidom.parseString(source.read('word/styles.xml'))
        # Accept an explicit table style by internal ID or displayed Word name.
        table_styles = {}
        for style in styles.getElementsByTagNameNS(W, 'style'):
            if style.getAttributeNS(W, 'type') == 'table':
                sid = style.getAttributeNS(W, 'styleId')
                table_styles[sid] = sid
                for name in children(style, 'name'):
                    table_styles.setdefault(name.getAttributeNS(W, 'val'), sid)
        # Unlike caption-field conversion, table finishing also handles tables
        # in footnotes/endnotes. Accumulate edits in memory until counts match.
        for member in ('word/document.xml', 'word/footnotes.xml', 'word/endnotes.xml'):
            if member not in source.namelist():
                continue
            document = minidom.parseString(source.read(member))
            tagged = set()
            changed = False
            for comment in list(comments(document)):
                if not comment.data.startswith(MARKER):
                    continue
                requested = bytes.fromhex(comment.data[len(MARKER):]).decode('utf-8')
                # The nearest enclosing table owns the marker. This distinction
                # matters for data tables nested inside other tables.
                table = comment.parentNode
                while table and not (table.nodeType == Node.ELEMENT_NODE
                                     and table.namespaceURI == W and table.localName == 'tbl'):
                    table = table.parentNode
                if table is None or table in tagged:
                    raise ValueError('Invalid data-table marker in Word output.')
                # Honor available explicit styles, including borderless ones;
                # an absent/unknown style falls back to the visible grid.
                style = table_styles.get(requested, DATA_STYLE)
                if style == DATA_STYLE:
                    ensure_style(styles, DATA_STYLE, True)
                set_style(table, style)
                tagged.add(table)
                comment.parentNode.removeChild(comment)
                count += 1
                changed = True
            for table in document.getElementsByTagNameNS(W, 'tbl'):
                if table in tagged:
                    continue
                props = children(table, 'tblPr')
                ids = children(props[0], 'tblStyle') if props else []
                # Quarto/Pandoc-generated wrappers use Table. Do not alter
                # independently styled raw OpenXML tables supplied by a user.
                if ids and ids[0].getAttributeNS(W, 'val') == 'Table':
                    ensure_style(styles, LAYOUT_STYLE, False)
                    set_style(table, LAYOUT_STYLE)
                    layout_count += 1
                    changed = True
            if changed:
                replacements[member] = document.toxml(encoding='utf-8')
            document.unlink()
        # Refuse incomplete marking before writing anything back. This catches
        # a missing filter or a filter placed after Quarto creates layout tables.
        if count != expected_tables:
            raise ValueError(f'Table verification failed: expected {expected_tables} data tables, '
                             f'found {count} markers. Check that table-borders.lua runs before quarto.')
        if not count and not layout_count:
            styles.unlink()
            return 0, 0
        replacements['word/styles.xml'] = styles.toxml(encoding='utf-8')
        styles.unlink()
        # Stage a complete ZIP beside the output, keeping unchanged member bytes
        # and metadata. Close the source ZIP before replacing it (Windows locks).
        # Atomic replacement applies to this finishing step, not the whole build.
        temporary = path.with_name(path.name + '.tables-tmp')
        if temporary.exists():
            raise ValueError(f'Remove the previous unfinished temporary file before retrying: {temporary}')
        try:
            with ZipFile(temporary, 'w') as target:
                for info in source.infolist():
                    target.writestr(info, replacements.get(info.filename, source.read(info.filename)))
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return count, layout_count
