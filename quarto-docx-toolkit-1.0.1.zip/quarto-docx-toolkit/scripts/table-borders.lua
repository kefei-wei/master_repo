-- Runs before Quarto creates layout tables. Tag each actual Markdown table
-- inside its first cell so the DOCX finisher can identify it unambiguously.
-- The comment is removed from the final DOCX and is never visible text.
if not FORMAT:match('docx') then return {} end

local function tag_table(t)
  -- Find the first available cell across table head, body and foot sections.
  -- Cell count is not used to decide whether this is a data table: one-cell
  -- tables authored in Markdown are genuine data tables too.
  local cell
  if #t.head.rows > 0 then cell = t.head.rows[1].cells[1] end
  for _, body in ipairs(t.bodies) do
    if not cell and #body.head > 0 then cell = body.head[1].cells[1] end
    if not cell and #body.body > 0 then cell = body.body[1].cells[1] end
  end
  if not cell and #t.foot.rows > 0 then cell = t.foot.rows[1].cells[1] end
  if not cell then error('Cannot style an empty table without cells.') end
  local style = t.attributes['custom-style'] or ''
  -- Quarto can move custom-style to the float wrapper, where Pandoc treats
  -- it as a paragraph style. Carry the value in a marker instead.
  t.attributes['custom-style'] = nil
  -- UTF-8 byte hex avoids XML-comment restrictions and escaping problems in
  -- style names. docx_tables.py decodes the same protocol after DOCX rendering.
  local hex = style:gsub('.', function(c) return string.format('%02x', string.byte(c)) end)
  cell.contents:insert(1, pandoc.RawBlock('openxml', '<!--toolkit-data-table:' .. hex .. '-->'))
  return t
end

return {
  {FloatRefTarget = function(float)
    -- Quarto's reader may already have lifted a captioned table's attributes
    -- onto its float before user filters run. Return the style to the table.
    if float.type ~= 'Table' then return nil end
    local style = float.attributes['custom-style']
    if not style then return nil end
    -- Assign the float's style only to its first contained table; nested tables
    -- may have their own styles and must not inherit this attribute accidentally.
    local assigned = false
    float.content = pandoc.Div(float.content):walk({
      traverse = 'topdown',
      Table = function(t)
        if not assigned then
          t.attributes['custom-style'] = style
          assigned = true
        end
        return t
      end
    }).content
    float.attributes['custom-style'] = nil
    return float
  end},
  -- A separate second pass tags every table after float styles are restored.
  {Table = tag_table}
}
