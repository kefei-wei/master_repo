@echo off
REM Keep this launcher's environment changes local to the batch invocation.
setlocal
REM An explicit interpreter override wins. Its version is the user's responsibility.
if defined TOOLKIT_PYTHON goto custom
REM Probe the Python 3 launcher silently. An older interpreter exits with code 1.
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto launcher
REM Fall back to python on PATH if the launcher is missing or too old.
python -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto python
REM No supported default interpreter was found. Report failure to the caller.
echo ERROR: Python 3.10 or later is required. Install Python or set TOOLKIT_PYTHON to python.exe. 1>&2
exit /b 1
REM Quote the override path so approved installations may contain spaces.
:custom
"%TOOLKIT_PYTHON%" %*
exit /b %errorlevel%
REM Forward the script and its arguments without altering their command syntax.
:launcher
py -3 %*
exit /b %errorlevel%
REM Return immediately after Python so its success or failure reaches build.bat.
:python
python %*
exit /b %errorlevel%
