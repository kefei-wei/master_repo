@echo off
REM Launch the build subcommand using scripts beside this batch file.
REM The dp0 expansion makes script lookup independent of the current directory.
REM Forward all caller arguments and return Python's exit status unchanged.
call "%~dp0run-python.bat" "%~dp0toolkit.py" build %*
exit /b %errorlevel%
