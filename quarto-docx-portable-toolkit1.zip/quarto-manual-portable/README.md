# Portable Word to Quarto toolkit (Python + batch)

Copy this entire folder to another Windows computer to import Word documents, edit Quarto Markdown (QMD), and export Word and standalone HTML review files. The prepared CONCLIFE manual is included.

**This version uses Python and `.bat` launchers. It contains no PowerShell scripts, never launches PowerShell, and needs no execution-policy changes.** If batch files are also restricted, use the direct Python commands below.

## 1. Set up the computer

Install your company's approved versions of:

- [Python for Windows](https://www.python.org/downloads/windows/), version 3.10 or later.
- [Quarto for Windows](https://quarto.org/docs/get-started/), which includes Pandoc.

Microsoft Word is not required for conversion. Use Word or another word processor to inspect the exported document's page layout.

Extract the ZIP, then open **Command Prompt** (Start menu: type `cmd`). These examples assume the extracted folder is `C:\Work\quarto-manual-portable`:

```bat
cd /d "C:\Work\quarto-manual-portable"
py -3 --version
quarto --version
```

If your Python command is `python` instead of `py -3`, substitute `python` in the examples. The batch launchers try `py -3` first, then `python`.

For HTML exports containing WMF/EMF pictures (including the supplied manual), install Pillow into that same Python environment:

```bat
py -3 -m pip install -r requirements.txt
```

Pillow is not needed for Word export, DOCX import, or HTML using only browser-compatible pictures such as PNG/JPEG. WMF/EMF previews use [Pillow's Windows renderer](https://pillow.readthedocs.io/en/stable/handbook/image-file-formats.html#wmf-emf). The requirement is Pillow 12.3 or later in the 12.x series. Without package-download access, have IT install it from an approved package source or wheel.

For Python that is not on PATH, set its executable for this Command Prompt session:

```bat
set "TOOLKIT_PYTHON=C:\Approved Python\python.exe"
"%TOOLKIT_PYTHON%" -m pip install -r requirements.txt
```

## 2. Convert another Word document to QMD

From the toolkit folder, replace the input path and run:

```bat
scripts\import-docx.bat "C:\Work\other-manual.docx"
```

The importer creates:

```text
projects/other-manual/
  other-manual.qmd   <- edit this file
  original.docx     <- unchanged source copy
  reference.docx    <- Word styles and page settings
  _quarto.yml       <- configuration
  review.css        <- HTML appearance
  assets/           <- extracted pictures, when present
```

The input file is unchanged. The importer retains many named styles as Markdown attributes. It never overwrites an existing project. To import a revised file while preserving existing edits:

```bat
scripts\import-docx.bat "C:\Work\other-manual.docx" --project-name other-manual-v2
```

Names must start with a letter or number; use letters, numbers, hyphens, underscores or periods. Avoid consecutive periods, trailing periods and Windows reserved names. `original` and `reference` are reserved to protect the source and template. Spaces in input filenames become underscores in the default project name; the importer prints the resulting path.

## 3. Edit the QMD

Open `projects/other-manual/other-manual.qmd` in a text editor such as VS Code. You can add or remove sentences, paragraphs, sections, tables and pictures. Keep backups before large changes.

Use blank lines between paragraphs. Heading levels use `#`, `##`, and `###`:

```markdown
# New section

A paragraph with **bold** and *italic* text.

## Subsection

- First item
- Second item
```

For a new image, copy a PNG/JPEG to that project's `assets/` folder and insert:

```markdown
![New setup screen.](assets/new-setup.png){#fig-new-setup width="5in"}

See @fig-new-setup for the new screen.
```

For a simple table:

```markdown
| Material | Density |
|:---------|--------:|
| Concrete | 2350    |

: Material densities. {#tbl-densities}

See @tbl-densities for the values.
```

Use unique `fig-` and `tbl-` labels. When deleting content, also update references to it. Keep matching `:::` div markers and style attributes around imported content to retain those styles. New paragraphs use the reference's default paragraph styles; to reuse a custom style, copy its style wrapper from similar imported content.

## 4. Export the edited QMD to Word

```bat
scripts\build.bat --project "projects\other-manual" --format docx
```

Open `projects/other-manual/output/other-manual.docx`. Inspect headings, tables, pictures and page breaks. Builds replace the previous export in `output/`; save a separate copy to keep older versions.

To change formatting permanently, edit the **Word styles** in `reference.docx` and rebuild. Changes made only to the generated Word document will be replaced by the next build.

## 5. Create an HTML review file

```bat
scripts\build.bat --project "projects\other-manual" --format html
```

Open `projects/other-manual/output/other-manual.html` in a browser. Images, scripts and CSS are embedded, so you can send this one HTML file to a reviewer. HTML is for reviewing content and navigation; it does not reproduce Word pagination.

WMF/EMF pictures under the project's `assets/` folder are converted to `*-review.png` previews automatically. Original vector pictures remain available for Word. Use PNG/JPEG for newly added pictures when possible.

## Use the supplied manual

Edit the root `usermanual.qmd`, then run:

```bat
scripts\build.bat --format docx
scripts\build.bat --format html
```

Outputs are `output/usermanual.docx` and `output/usermanual.html`. The unchanged source copy is **`original-usermanual.docx`**. Its distinct name prevents Quarto's temporary export file from overwriting it. The reference is `usermanual-reference.docx`.

The manual's Lua filters apply its chapter, section, table and caption styles. Other imported documents use their own reference file and do not receive the CONCLIFE-specific filters.

## Run Python directly (without batch files)

These commands perform the same operations from the toolkit folder:

```bat
py -3 scripts\toolkit.py import "C:\Work\other-manual.docx"
py -3 scripts\toolkit.py build --project "projects\other-manual" --format docx
py -3 scripts\toolkit.py build --project "projects\other-manual" --format html
```

Use `python` or a quoted full path to `python.exe` instead of `py -3` if needed.

## Options and troubleshooting

- **Quarto not found:** add `--quarto "C:\Approved Tools\Quarto\bin\quarto.exe"` to import or build. Standard Windows installations and PATH are checked.
- **Multiple QMD files:** add `--input-file "chapter.qmd"` to select one at the project root.
- **Paths:** quote paths containing spaces. `--project` is relative to the toolkit folder regardless of your current directory. Input DOCX paths are relative to your current directory; absolute paths are easiest.
- **Project already exists:** choose another `--project-name`. A failed import may leave a partial folder; inspect it before deleting it or retry under a new name.
- **Output filename exists beside QMD:** move or rename that file. Quarto temporarily creates output there before moving it into `output/`; the build script refuses collisions to protect source documents.
- **Pillow missing:** install `requirements.txt` using the interpreter the launcher selects, or set `TOOLKIT_PYTHON` explicitly. PNG/JPEG files do not need conversion.
- **Conversion error:** commands return a nonzero exit code and print the error. Check the referenced file path and Quarto message.
- **Help:** run `scripts\import-docx.bat --help` or `scripts\build.bat --help`.

## Script roles and folder contents

| File | Purpose |
|---|---|
| `scripts/import-docx.bat` | Launch Python's DOCX importer. |
| `scripts/build.bat` | Launch Python's Word/HTML exporter. |
| `scripts/prepare-html-images.bat` | Regenerate previews separately; accepts `--project`. HTML builds already do this. |
| `scripts/run-python.bat` | Choose Python, forward arguments and preserve exit codes. |
| `scripts/toolkit.py` | Import, export, path validation and WMF/EMF preview logic. |
| `scripts/html-images.lua` | Substitute PNG previews in HTML only. |
| `scripts/manual-style.lua` | Supplied manual's chapter, section, table and list styles. |
| `scripts/docx-layout.lua` | Supplied manual's Word picture and caption layout. |
| `requirements.txt` | Optional Pillow dependency for WMF/EMF HTML previews. |
| `_quarto.yml`, `styles/`, `assets/` | Manual configuration, CSS and pictures. |
| `projects/` | Imported document projects. |
| `output/` | Supplied manual's Word and HTML exports. |

Keep the whole toolkit together. Imported projects use the shared `scripts/html-images.lua` through a relative path. The earlier `convert.py` and `restore-format.py` used a fixed-block workflow that restricted additions/deletions; they are not required here.

## Style preservation and limits

A Word reference supplies named styles and page settings; it does not reproduce every direct-formatting or layout feature. Its body text is not inserted into the export. Complex floating layouts, text boxes, section breaks, embedded objects and tracked changes may need adjustment. Imported literal numbering may also need editing. Check an initial Word export before extensive editing of a new document.

The supplied manual has a customized reference and filters from the earlier verified conversion. Other documents receive a general conversion using their own styles. This supports structural editing but does not guarantee identical pagination after content changes.

## Validation

The Python/batch version is checked on Windows with Quarto 1.10.18 and Pillow 12.3.0: import of a second DOCX, Word and HTML exports, the supplied manual, picture conversion, argument handling and errors. The manual's exported Word body and style XML are compared with the previously verified export. HTML structure and embedded images are checked; inspect the HTML in your browser and the DOCX in Word for final visual review.
