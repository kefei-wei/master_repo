"""Portable DOCX / Quarto commands. No PowerShell or Microsoft Word required."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

BUNDLE = Path(__file__).resolve().parent.parent
CONFIG = """project:
  type: default
  output-dir: output
format:
  docx:
    reference-doc: reference.docx
    toc: false
    number-sections: false
  html:
    embed-resources: true
    toc: true
    css: review.css
filters:
  - ../../scripts/html-images.lua
  - quarto
execute:
  enabled: false
"""


def find_quarto(explicit: str | None) -> Path:
    if explicit:
        candidate = Path(explicit).expanduser().resolve()
        if not candidate.is_file():
            raise ValueError(f"Quarto executable not found: {candidate}")
        return candidate
    candidates = []
    for variable, suffix in [("ProgramFiles", "Quarto/bin/quarto.exe"),
                             ("LOCALAPPDATA", "Programs/Quarto/bin/quarto.exe")]:
        if os.environ.get(variable):
            candidates.append(Path(os.environ[variable]) / suffix)
    located = shutil.which("quarto")
    if located:
        path = Path(located)
        candidates.extend([path.with_suffix(".exe"), path])
    for path in candidates:
        if path.is_file():
            return path.resolve()
    raise ValueError("Quarto was not found. Install Quarto or use --quarto PATH.")


def project_path(value: str) -> Path:
    path = Path(value).expanduser()
    return (path if path.is_absolute() else BUNDLE / path).resolve()


def import_docx(args: argparse.Namespace) -> None:
    source = Path(args.input_docx).expanduser().resolve()
    if source.suffix.lower() != ".docx" or not source.is_file():
        raise ValueError(f"Input must be an existing .docx file: {source}")
    name = args.project_name or re.sub(r"[^A-Za-z0-9._-]", "_", source.stem)
    if (not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", name) or ".." in name
            or name.endswith(".") or name.lower() in {"original", "reference"}
            or re.fullmatch(r"(?i)(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\..*)?", name)):
        raise ValueError("Use --project-name with a name starting with a letter or number; "
                         "use only letters, numbers, periods, underscores and hyphens. "
                         "Avoid '..', trailing periods, Windows reserved names, original and reference.")
    target = BUNDLE / "projects" / name
    if target.exists():
        raise ValueError(f"Project already exists: {target}. Choose another --project-name to preserve edits.")
    quarto = find_quarto(args.quarto)
    pandoc = quarto.parent / "tools" / ("pandoc.exe" if os.name == "nt" else "pandoc")
    if not pandoc.is_file():
        raise ValueError(f"Cannot find Pandoc bundled with Quarto: {pandoc}")
    target.mkdir(parents=True)
    # Distinct source/template names avoid Quarto's temporary output filename.
    shutil.copy2(source, target / "original.docx")
    shutil.copy2(source, target / "reference.docx")
    shutil.copy2(BUNDLE / "styles" / "review.css", target / "review.css")
    (target / "_quarto.yml").write_text(CONFIG, encoding="utf-8")
    subprocess.run([str(pandoc), str(source), "-f", "docx+styles", "-t",
                    "markdown+fenced_divs+bracketed_spans", "--wrap=none",
                    "--extract-media=assets", "-o", name + ".qmd"], cwd=target, check=True)
    print(f"Created {target}\nEdit {name}.qmd, then run:")
    print(f'scripts\\build.bat --project "projects/{name}" --format docx')


def prepare_images(project: Path) -> None:
    vectors = sorted(p for p in (project / "assets").rglob("*")
                     if p.is_file() and p.suffix.lower() in {".wmf", ".emf"})
    if not vectors:
        return
    if os.name != "nt":
        raise ValueError("WMF/EMF preview conversion requires Windows. Use PNG/JPEG images instead.")
    try:
        import PIL
        from PIL import Image
    except ImportError as exc:
        raise ValueError("WMF/EMF previews require Pillow. Run: python -m pip install -r requirements.txt") from exc
    version = tuple(int(x) for x in PIL.__version__.split(".")[:2])
    if version < (12, 3):
        raise ValueError("WMF/EMF previews require Pillow 12.3 or later. Install requirements.txt.")
    for source in vectors:
        target = source.with_name(source.stem + "-review.png")
        with Image.open(source) as image:
            # Render the vector at higher resolution, bounded to a 2048px edge.
            scale = min(2.5, 2048 / max(image.size))
            dpi = image.info.get("dpi", 72)
            if not isinstance(dpi, tuple):
                dpi = (dpi, dpi)
            image.load(dpi=(dpi[0] * scale, dpi[1] * scale))
            image.convert("RGB").save(target, "PNG")
        print(f"Preview: {target}", flush=True)


def build(args: argparse.Namespace) -> None:
    project = project_path(args.project)
    if not (project / "_quarto.yml").is_file():
        raise ValueError(f"No _quarto.yml found in project: {project}")
    if args.input_file:
        source = (project / args.input_file).resolve()
    else:
        sources = list(project.glob("*.qmd"))
        if len(sources) != 1:
            raise ValueError("Project must contain exactly one QMD, or specify --input-file NAME.qmd.")
        source = sources[0].resolve()
    if source.parent != project or source.suffix.lower() != ".qmd" or not source.is_file():
        raise ValueError("The selected QMD must be a file directly inside the project folder.")
    # Quarto stages output beside the QMD before moving it into output/.
    staged_output = source.with_suffix("." + args.format)
    if staged_output.exists():
        raise ValueError(f"Move or rename {staged_output.name} before building: Quarto uses that "
                         "filename temporarily. Keep original Word files under a different name.")
    quarto = find_quarto(args.quarto)
    if args.format == "html":
        prepare_images(project)
    subprocess.run([str(quarto), "render", source.name, "--to", args.format], cwd=project, check=True)
    print(f"Build finished. See {project / 'output'}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    importer = commands.add_parser("import", help="Import another Word document into projects/.")
    importer.add_argument("input_docx", help="DOCX path, relative to your current directory or absolute.")
    importer.add_argument("--project-name")
    importer.add_argument("--quarto", help="Full path to the Quarto executable.")
    builder = commands.add_parser("build", help="Build Word or standalone HTML.")
    builder.add_argument("--project", default=".", help="Absolute path or path relative to toolkit folder.")
    builder.add_argument("--input-file", help="QMD filename inside the project.")
    builder.add_argument("--format", choices=["docx", "html"], default="docx")
    builder.add_argument("--quarto", help="Full path to the Quarto executable.")
    images = commands.add_parser("images", help="Regenerate WMF/EMF PNG previews (also done by HTML build).")
    images.add_argument("--project", default=".")
    args = parser.parse_args()
    try:
        if args.command == "import":
            import_docx(args)
        elif args.command == "build":
            build(args)
        else:
            project = project_path(args.project)
            if not project.is_dir():
                raise ValueError(f"Project does not exist: {project}")
            prepare_images(project)
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
