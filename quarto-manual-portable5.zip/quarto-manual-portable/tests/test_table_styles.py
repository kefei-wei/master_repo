"""Standard-library tests: python -m unittest discover -s tests -v"""
from pathlib import Path
import sys
import tempfile
import unittest
from xml.etree import ElementTree as ET
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from docx_tables import finish_tables
from toolkit import ensure_table_filter

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}
STYLES = f'''<w:styles xmlns:w="{W}">
<w:style w:type="table" w:styleId="TableNormal"><w:name w:val="Normal Table"/></w:style>
<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/>
<w:tblPr><w:tblBorders><w:top w:val="double"/></w:tblBorders></w:tblPr></w:style>
</w:styles>'''


def table(content):
    return '<w:tbl><w:tblPr><w:tblStyle w:val="Table"/></w:tblPr><w:tr><w:tc>' + content + '</w:tc></w:tr></w:tbl>'


def marked(style='', text='Data'):
    return table('<!--toolkit-data-table:' + style.encode().hex() + '--><w:p><w:r><w:t>' + text + '</w:t></w:r></w:p>')


class TableStyles(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'test.docx'

    def create(self, content, note=None):
        with ZipFile(self.path, 'w') as z:
            z.writestr('word/document.xml', f'<w:document xmlns:w="{W}"><w:body>{content}</w:body></w:document>')
            z.writestr('word/styles.xml', STYLES)
            z.writestr('word/media/untouched.bin', b'preserve media')
            if note:
                z.writestr('word/footnotes.xml', f'<w:footnotes xmlns:w="{W}"><w:footnote w:id="1">{note}</w:footnote></w:footnotes>')

    def read(self, member):
        with ZipFile(self.path) as z:
            return ET.fromstring(z.read(member))

    def test_single_cell_data_is_distinct_from_single_cell_wrapper(self):
        self.create(table(marked()))
        self.assertEqual(finish_tables(self.path, 1), (1, 1))
        doc = self.read('word/document.xml')
        styles = [s.get(f'{{{W}}}val') for s in doc.findall('.//w:tblStyle', NS)]
        self.assertEqual(styles, ['ToolkitLayoutTable', 'ToolkitDataTable'])
        definitions = self.read('word/styles.xml')
        for identifier, value in [('ToolkitDataTable', 'single'), ('ToolkitLayoutTable', 'nil')]:
            borders = definitions.findall(f'w:style[@w:styleId="{identifier}"]/w:tblPr/w:tblBorders/*', NS)
            self.assertEqual(len(borders), 6)
            self.assertTrue(all(b.get(f'{{{W}}}val') == value for b in borders))
        with ZipFile(self.path) as z:
            self.assertNotIn(b'toolkit-data-table:', z.read('word/document.xml'))
            self.assertEqual(z.read('word/media/untouched.bin'), b'preserve media')

    def test_explicit_style_and_borderless_choice_are_preserved(self):
        self.create(marked('Table Grid') + marked('TableNormal'))
        self.assertEqual(finish_tables(self.path, 2), (2, 0))
        ids = [s.get(f'{{{W}}}val') for s in self.read('word/document.xml').findall('.//w:tblStyle', NS)]
        self.assertEqual(ids, ['TableGrid', 'TableNormal'])
        self.assertEqual(self.read('word/styles.xml').find('w:style[@w:styleId="TableGrid"]/w:tblPr/w:tblBorders/w:top', NS).get(f'{{{W}}}val'), 'double')

    def test_missing_style_falls_back_to_grid(self):
        self.create(marked('UnavailableStyle'))
        finish_tables(self.path, 1)
        self.assertEqual(self.read('word/document.xml').find('.//w:tblStyle', NS).get(f'{{{W}}}val'), 'ToolkitDataTable')

    def test_nested_data_tables_and_footnotes(self):
        self.create(marked(text='Outer').replace('</w:tc>', marked('TableGrid') + '</w:tc>', 1), note=marked())
        self.assertEqual(finish_tables(self.path, 3), (3, 0))

    def test_missing_markers_abort_without_rewriting_document(self):
        self.create(table('<w:p/>'))
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, 'expected 1 data tables, found 0'):
            finish_tables(self.path, 1)
        self.assertEqual(self.path.read_bytes(), before)

    def test_configuration_upgrade_is_once_and_preserves_backup(self):
        project = Path(self.temp.name)
        config = project / '_quarto.yml'
        before = 'filters:\n  - quarto\n  - existing-caption.lua\nformat:\n  docx: default\n'
        config.write_text(before, encoding='utf-8')
        ensure_table_filter(project)
        after = config.read_bytes()
        ensure_table_filter(project)
        self.assertEqual(config.read_bytes(), after)
        self.assertEqual((project / '_quarto.yml.before-table-fix').read_text(encoding='utf-8'), before)
        self.assertEqual(after.count(b'table-borders.lua'), 1)
        self.assertLess(after.index(b'table-borders.lua'), after.index(b'- quarto'))


if __name__ == '__main__':
    unittest.main()
