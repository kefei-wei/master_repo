"""Caption fields preserve document content and survive structural editing."""
from pathlib import Path
import sys
import tempfile
import unittest
from xml.etree import ElementTree as ET
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from docx_fields import finish_fields

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}


def caption(kind, number, content='Caption with content', anchor=None):
    style = 'ImageCaption' if kind == 'Figure' else 'TableCaption'
    anchor = anchor or ('fig-' if kind == 'Figure' else 'tbl-') + str(number)
    return (f'<w:bookmarkStart w:id="{number}" w:name="{anchor}"/>'
            f'<w:p><w:pPr><w:pStyle w:val="{style}"/><w:jc w:val="center"/></w:pPr>'
            f'<w:r><w:t>{kind}\u00a0</w:t></w:r>'
            f'<w:r><w:rPr><w:b/></w:rPr><w:t>{number}</w:t></w:r>'
            f'<w:r><w:t>: </w:t></w:r><w:r><w:rPr><w:i/></w:rPr><w:t>{content}</w:t></w:r>'
            f'</w:p><w:bookmarkEnd w:id="{number}"/>')


def reference(anchor, value):
    return (f'<w:p><w:hyperlink w:anchor="{anchor}"><w:r><w:rPr>'
            f'<w:rStyle w:val="Hyperlink"/></w:rPr><w:t>{value}</w:t></w:r>'
            '</w:hyperlink></w:p>')


class CaptionFields(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'caption.docx'

    def create(self, content):
        with ZipFile(self.path, 'w') as z:
            z.writestr('word/document.xml', f'<w:document xmlns:w="{W}"><w:body>{content}</w:body></w:document>')
            z.writestr('word/styles.xml', f'<w:styles xmlns:w="{W}"/>')
            z.writestr('word/media/picture.png', b'picture unchanged')

    def document(self):
        with ZipFile(self.path) as z:
            return ET.fromstring(z.read('word/document.xml'))

    def test_fields_inside_layout_table_keep_text_styles_and_media(self):
        content = '<w:tbl><w:tr><w:tc>' + caption('Figure', 1, 'An italic caption') + '</w:tc></w:tr></w:tbl>'
        self.create(content + caption('Table', 1))
        before = self.document()
        self.assertEqual(finish_fields(self.path), (1, 1, 0))
        after = self.document()
        self.assertEqual([t.text for t in before.findall('.//w:t', NS)], [t.text for t in after.findall('.//w:t', NS)])
        fields = after.findall('.//w:fldSimple', NS)
        self.assertEqual([f.get(f'{{{W}}}instr').strip() for f in fields], ['SEQ Figure \\* ARABIC', 'SEQ Table \\* ARABIC'])
        self.assertIsNotNone(fields[0].find('w:r/w:rPr/w:b', NS))
        self.assertEqual(len(after.findall('.//w:rPr/w:i', NS)), 2)
        self.assertEqual(len(after.findall('.//w:tbl', NS)), 1)
        with ZipFile(self.path) as z:
            self.assertEqual(z.read('word/media/picture.png'), b'picture unchanged')

    def test_forward_reference_and_number_only_reference(self):
        self.create(reference('fig-1', 'Figure\u00a01') + caption('Figure', 1)
                    + reference('fig-1', '1') + reference('fig-1', 'the setup'))
        self.assertEqual(finish_fields(self.path), (1, 0, 2))
        doc = self.document()
        links = doc.findall('.//w:hyperlink', NS)
        bookmark = next(b.get(f'{{{W}}}name') for b in doc.findall('.//w:bookmarkStart', NS)
                        if b.get(f'{{{W}}}name').startswith('QCaption_'))
        for link in links[:2]:
            self.assertEqual(link.find('w:fldSimple', NS).get(f'{{{W}}}instr').strip(), 'REF ' + bookmark)
        self.assertIsNone(links[2].find('w:fldSimple', NS))

    def test_two_digit_number_split_between_formatted_runs(self):
        last = caption('Figure', 10).replace('<w:t>10</w:t>', '<w:t>1</w:t></w:r><w:r><w:rPr><w:i/></w:rPr><w:t>0</w:t>')
        self.create(''.join(caption('Figure', n) for n in range(1, 10)) + last)
        self.assertEqual(finish_fields(self.path), (10, 0, 0))
        field = self.document().findall('.//w:fldSimple', NS)[-1]
        self.assertEqual(''.join(t.text for t in field.findall('.//w:t', NS)), '10')
        self.assertEqual(len(field.findall('w:r', NS)), 2)

    def test_unsupported_numbering_is_atomic(self):
        for number in ['1.1', '2', 'A']:
            with self.subTest(number=number):
                self.create(caption('Figure', number).replace(f'w:id="{number}"', 'w:id="1"'))
                before = self.path.read_bytes()
                with self.assertRaises(ValueError):
                    finish_fields(self.path)
                self.assertEqual(self.path.read_bytes(), before)

    def test_repeated_finish_preserves_existing_fields(self):
        self.create(caption('Figure', 1) + reference('fig-1', 'Figure 1'))
        finish_fields(self.path)
        before = self.path.read_bytes()
        self.assertEqual(finish_fields(self.path), (1, 0, 0))
        self.assertEqual(self.path.read_bytes(), before)

    def test_prose_mention_is_not_a_caption(self):
        self.create('<w:p><w:r><w:t>Figure 1 is mentioned here.</w:t></w:r></w:p>')
        before = self.path.read_bytes()
        self.assertEqual(finish_fields(self.path), (0, 0, 0))
        self.assertEqual(self.path.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
