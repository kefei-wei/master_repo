-- Formatting rules only. No original content, block IDs, hashes or content map.
local chapter, section = 0, 0

function Header(el)
  if el.classes:includes('unnumbered') then return el end
  local prefix
  if el.level == 1 then
    chapter = chapter + 1
    section = 0
    prefix = 'CHAPTER ' .. chapter .. ': '
  elseif el.level == 2 then
    section = section + 1
    prefix = chapter .. '.' .. section .. ' '
  end
  if prefix then
    local content = pandoc.Inlines({pandoc.Str(prefix)})
    content:extend(el.content)
    el.content = content
  end
  return el
end

function Table(el)
  if not FORMAT:match('docx') then return el end
  -- Pandoc's DOCX table writer expects the style ID, unlike paragraph styles.
  el.attributes['custom-style'] = 'ManualTable'
  -- Apply the same cell paragraph style to every table, including newly added ones.
  local rows = pandoc.List()
  rows:extend(el.head.rows)
  for _, body in ipairs(el.bodies) do rows:extend(body.head); rows:extend(body.body) end
  rows:extend(el.foot.rows)
  -- Short tables stay together; long tables can span pages with repeating headers.
  local keep = #rows <= 8 and #pandoc.utils.stringify(el) < 2500
    and el.attributes['table-keep'] ~= 'false'
  for index, row in ipairs(rows) do
      local style = keep and index < #rows and 'Table Text Keep' or 'Table Text'
      local function cell_style(p)
        return pandoc.Div({pandoc.Para(p.content)}, pandoc.Attr('',{}, {['custom-style']=style}))
      end
      for _, cell in ipairs(row.cells) do
        cell.contents = pandoc.Pandoc(cell.contents):walk({Para=cell_style,Plain=cell_style}).blocks
      end
  end
  return el
end

local function list_spacing(el)
  if not FORMAT:match('docx') then return el end
  local last = el.content[#el.content]
  if last and #last > 0 and (last[#last].t == 'Plain' or last[#last].t == 'Para') then
    last[#last] = pandoc.Div({pandoc.Para(last[#last].content)},
      pandoc.Attr('',{}, {['custom-style']='List End'}))
  end
  return el
end
BulletList = list_spacing
OrderedList = list_spacing
