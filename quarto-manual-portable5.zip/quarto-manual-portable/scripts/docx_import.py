"""Prepare a temporary DOCX for Pandoc without changing the user's original."""
from xml.dom import minidom, Node
from zipfile import ZipFile

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def copy_caption_styles(source, destination):
    """Fill missing Pandoc caption styles using the source Word Caption style."""
    with ZipFile(source) as original, ZipFile(destination, "w") as output:
        for member in original.infolist():
            data = original.read(member.filename)
            if member.filename == "word/styles.xml":
                doc = minidom.parseString(data)
                styles = list(doc.getElementsByTagNameNS(W, "style"))
                caption = next((s for s in styles if s.getAttributeNS(W, "styleId").lower() == "caption"), None)
                known = {s.getAttributeNS(W, "styleId") for s in styles}
                changed = False
                for identifier, name in [("ImageCaption", "Image Caption"), ("TableCaption", "Table Caption")]:
                    if caption is not None and identifier not in known:
                        copied = caption.cloneNode(True)
                        copied.setAttributeNS(W, "w:styleId", identifier)
                        names = copied.getElementsByTagNameNS(W, "name")
                        if names:
                            names[0].setAttributeNS(W, "w:val", name)
                        doc.documentElement.appendChild(copied)
                        changed = True
                if changed:
                    data = doc.toxml(encoding="utf-8")
                doc.unlink()
            output.writestr(member, data)


def split_picture_runs(source, destination):
    """Pandoc reads only the first drawing in a run. Give each item its own run.

    minidom preserves the original namespace prefixes and declarations, including
    prefixes referenced by mc:Ignorable, unlike a default ElementTree rewrite.
    """
    changed = 0
    with ZipFile(source) as original, ZipFile(destination, "w") as output:
        for member in original.infolist():
            data = original.read(member.filename)
            if member.filename == "word/document.xml":
                doc = minidom.parseString(data)
                for run in list(doc.getElementsByTagNameNS(W, "r")):
                    children = [n for n in run.childNodes if n.nodeType == Node.ELEMENT_NODE]
                    pictures = [n for n in children if n.namespaceURI == W
                                and n.localName in {"drawing", "pict", "object"}]
                    if len(pictures) < 2:
                        continue
                    properties = next((n for n in children if n.namespaceURI == W
                                       and n.localName == "rPr"), None)
                    for child in children:
                        if child is properties:
                            continue
                        replacement = run.cloneNode(False)
                        if properties is not None:
                            replacement.appendChild(properties.cloneNode(True))
                        replacement.appendChild(child.cloneNode(True))
                        run.parentNode.insertBefore(replacement, run)
                    run.parentNode.removeChild(run)
                    changed += 1
                if changed:
                    data = doc.toxml(encoding="utf-8")
                doc.unlink()
            output.writestr(member, data)
    return changed
