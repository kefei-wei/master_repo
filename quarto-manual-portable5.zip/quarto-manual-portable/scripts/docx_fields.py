"""Native Word caption numbering and cross-references; standard library only.

Run after Quarto renders captions. Replace only the number, retaining paragraph
styles, labels, punctuation, emphasis, hyperlinks, and the surrounding layout.
"""
from collections import Counter
import hashlib
import os
from pathlib import Path
import re
from xml.dom import Node, minidom
from zipfile import ZipFile

from docx_tables import W, children, element

XML = 'http://www.w3.org/XML/1998/namespace'
CAPTION_STYLES = {'ImageCaption': 'Figure', 'TableCaption': 'Table'}
CAPTION_NAMES = {'Image Caption': 'Figure', 'Table Caption': 'Table'}


def descendants(node, local):
    return list(node.getElementsByTagNameNS(W, local))


def text(node):
    return ''.join(c.data for c in node.childNodes if c.nodeType == Node.TEXT_NODE)


def visible_text(node):
    return ''.join(text(t) for t in descendants(node, 't'))


def instructions(node):
    return ([f.getAttributeNS(W, 'instr') for f in descendants(node, 'fldSimple')]
            + [text(t) for t in descendants(node, 'instrText')])


def text_run(run, value):
    result = run.cloneNode(False)
    for prop in children(run, 'rPr'):
        result.appendChild(prop.cloneNode(True))
    t = element(run.ownerDocument, 't')
    t.setAttributeNS(XML, 'xml:space', 'preserve')
    t.appendChild(run.ownerDocument.createTextNode(value))
    result.appendChild(t)
    return result


def replace_number(container, start, end, instruction, bookmark=None):
    """Replace a text range across runs, keeping the number's run formatting.

    Caption numbers and resolved Quarto links are direct text runs. Refuse
    unusual nested/field content rather than flattening and losing it.
    """
    runs = []
    offset = 0
    for run in children(container, 'r'):
        value = visible_text(run)
        next_offset = offset + len(value)
        if offset < end and next_offset > start:
            unsupported = [c for c in run.childNodes if c.nodeType == Node.ELEMENT_NODE
                           and (c.namespaceURI != W or c.localName not in {'rPr', 't', 'lastRenderedPageBreak'})]
            if unsupported:
                raise ValueError('Caption/reference number contains unsupported Word run content.')
            runs.append((run, value, max(0, start - offset), min(len(value), end - offset)))
        offset = next_offset
    if offset != len(visible_text(container)) or not runs:
        raise ValueError('Caption/reference number is nested in unsupported Word markup.')
    first, first_text, first_start, _ = runs[0]
    last, last_text, _, last_end = runs[-1]
    doc = container.ownerDocument
    field = element(doc, 'fldSimple', instr=' ' + instruction + ' ', dirty='true')
    for run, value, begin, stop in runs:
        field.appendChild(text_run(run, value[begin:stop]))
    if first_start:
        container.insertBefore(text_run(first, first_text[:first_start]), first)
    if bookmark:
        bid, name = bookmark
        container.insertBefore(element(doc, 'bookmarkStart', id=bid, name=name), first)
    container.insertBefore(field, first)
    if bookmark:
        container.insertBefore(element(doc, 'bookmarkEnd', id=bid), first)
    if last_end < len(last_text):
        container.insertBefore(text_run(last, last_text[last_end:]), last)
    for run, _, _, _ in runs:
        container.removeChild(run)


def caption_bookmarks(document):
    """Map each caption paragraph to enclosing Quarto figure/table bookmarks.

    Word bookmarks are ranges, not XML parents. Traverse in document order so
    this works for captions inside layout tables and after image paragraphs.
    """
    active = {}
    found = {}

    def visit(node, paragraph=None):
        if node.nodeType == Node.ELEMENT_NODE and node.namespaceURI == W:
            if node.localName == 'p':
                paragraph = node
            elif node.localName == 'bookmarkStart':
                active[node.getAttributeNS(W, 'id')] = node.getAttributeNS(W, 'name')
            elif node.localName == 'bookmarkEnd':
                active.pop(node.getAttributeNS(W, 'id'), None)
            elif node.localName == 't' and paragraph is not None:
                found.setdefault(paragraph, list(active.values()))
        for child in node.childNodes:
            visit(child, paragraph)

    visit(document)
    return found


def finish_fields(path: Path):
    """Return native Figure, Table and converted REF counts; commit atomically.

    Supports continuous Arabic numbering (the toolkit default). Other numbering
    schemes fail clearly rather than producing fields that renumber incorrectly.
    """
    path = Path(path)
    counts = Counter()
    with ZipFile(path) as source:
        document = minidom.parseString(source.read('word/document.xml'))
        styles = minidom.parseString(source.read('word/styles.xml'))
        caption_styles = dict(CAPTION_STYLES)
        for style in descendants(styles, 'style'):
            names = children(style, 'name')
            if names and names[0].getAttributeNS(W, 'val') in CAPTION_NAMES:
                caption_styles[style.getAttributeNS(W, 'styleId')] = CAPTION_NAMES[names[0].getAttributeNS(W, 'val')]
        associations = caption_bookmarks(document)
        bookmarks = descendants(document, 'bookmarkStart')
        existing_names = {b.getAttributeNS(W, 'name') for b in bookmarks}
        next_id = max((int(b.getAttributeNS(W, 'id')) for b in bookmarks), default=-1) + 1
        references = {}
        changed = False
        for paragraph in descendants(document, 'p'):
            props = children(paragraph, 'pPr')
            ids = children(props[0], 'pStyle') if props else []
            kind = caption_styles.get(ids[0].getAttributeNS(W, 'val')) if ids else None
            if not kind:
                continue
            # Re-running on an already finished DOCX never duplicates fields.
            existing = [i for i in instructions(paragraph)
                        if re.match(r'\s*SEQ\s+' + kind + r'\b', i, re.I)]
            if existing:
                counts[kind] += len(existing)
                continue
            label = visible_text(paragraph)
            if not label.strip():
                continue
            match = re.match(r'^(?:Figure|Fig\.?|Table|Tbl\.?)\s+(\d+)(?=[\s:.,;\-\u2013\u2014]|$)', label, re.I)
            if not match or re.match(r'[.\-]\d', label[match.end(1):]):
                raise ValueError('Native Word captions require Figure/Table labels with continuous '
                                 'Arabic numbers (1, 2, 3). Unsupported caption: ' + label[:100])
            number = match.group(1)
            counts[kind] += 1
            if int(number) != counts[kind]:
                raise ValueError(f'{kind} captions must use continuous numbering from 1; '
                                 f'expected {counts[kind]}, found {number}. Chapter/subfigure numbering '
                                 'needs a different Word field scheme.')
            prefix = 'fig-' if kind == 'Figure' else 'tbl-'
            anchors = [a for a in associations.get(paragraph, []) if a.startswith(prefix)]
            anchor = anchors[-1] if anchors else None
            key = anchor or f'{kind}-{number}'
            name = 'QCaption_' + hashlib.sha256(key.encode('utf-8')).hexdigest()[:24]
            if name in existing_names:
                raise ValueError('Duplicate caption bookmark: ' + key)
            existing_names.add(name)
            replace_number(paragraph, *match.span(1), f'SEQ {kind} \\* ARABIC',
                           bookmark=(next_id, name))
            next_id += 1
            if anchor:
                if anchor in references:
                    raise ValueError('More than one numbered caption shares bookmark: ' + anchor)
                references[anchor] = (name, number)
            changed = True

        for link in descendants(document, 'hyperlink'):
            target = references.get(link.getAttributeNS(W, 'anchor'))
            if not target or instructions(link):
                continue
            name, number = target
            match = re.search(r'(?<![\w.])' + re.escape(number) + r'$', visible_text(link))
            if not match:
                # Keep descriptive links ("the equipment setup") as authored.
                continue
            replace_number(link, *match.span(), f'REF {name}')
            counts['REF'] += 1
            changed = True

        if not changed:
            return counts['Figure'], counts['Table'], counts['REF']
        replacement = document.toxml(encoding='utf-8')
        temporary = path.with_name(path.name + '.fields-tmp')
        if temporary.exists():
            raise ValueError(f'Previous unfinished caption temporary file exists: {temporary}')
        try:
            with ZipFile(temporary, 'w') as target:
                for info in source.infolist():
                    target.writestr(info, replacement if info.filename == 'word/document.xml'
                                    else source.read(info.filename))
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return counts['Figure'], counts['Table'], counts['REF']
