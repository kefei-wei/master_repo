-- Convert DOCX caption structure into Quarto figure/table syntax on import.
-- Run on the DOCX AST, before Pandoc serializes it to Markdown.
local fig, tbl = 0, 0

local function caption_blocks(blocks)
  return pandoc.Pandoc(blocks):walk({
    Div = function(d) return d.content end,
    Span = function(s) return s.content end
  }).blocks
end

local function strip_label(blocks)
  -- Remove just the leading literal number; preserve emphasis and other inlines.
  local remaining = nil
  local text = pandoc.utils.stringify(blocks)
  local label = text:match('^[Ff]igure%s+[%d%.%-]+[%.:%s]*')
             or text:match('^[Tt]able%s+[%d%.%-]+[%.:%s]*')
  if not label then return blocks end
  remaining = #label
  return pandoc.Pandoc(blocks):walk({
    Str = function(s)
      if remaining == 0 then return nil end
      local take = math.min(remaining, #s.text)
      remaining = remaining - take
      return pandoc.Str(s.text:sub(take + 1))
    end,
    Space = function(s)
      if remaining > 0 then remaining = remaining - 1; return {} end
    end
  }).blocks
end

local function new_figure(contents, caption, attr)
  fig = fig + 1
  attr = attr or pandoc.Attr()
  if attr.identifier == '' then attr.identifier = 'fig-import-' .. fig end
  local blocks = pandoc.Blocks({})
  for _, block in ipairs(contents) do
    local images, other = {}, false
    if block.t == 'Para' or block.t == 'Plain' then
      for _, inline in ipairs(block.content) do
        if inline.t == 'Image' then table.insert(images, inline)
        elseif inline.t ~= 'Space' and inline.t ~= 'SoftBreak' then other = true end
      end
    end
    -- Quarto's DOCX float renderer otherwise keeps only the first image in
    -- a multi-image paragraph. Separate blocks preserve every picture.
    if #images > 1 and not other then
      for _, image in ipairs(images) do blocks:insert(pandoc.Para({image})) end
    else
      blocks:insert(block)
    end
  end
  blocks:extend(strip_label(caption_blocks(caption)))
  return pandoc.Div(blocks, attr)
end

local function only_images(block)
  if block.t ~= 'Para' and block.t ~= 'Plain' then return false end
  local count = 0
  for _, i in ipairs(block.content) do
    if i.t == 'Image' then count = count + 1
    elseif i.t ~= 'Space' and i.t ~= 'SoftBreak' then return false end
  end
  return count > 0
end

local function join_caption(blocks)
  local result = pandoc.Blocks({})
  for _, b in ipairs(blocks) do
    local style = b.t == 'Div' and (b.attributes['custom-style'] or ''):lower() or ''
    local previous = result[#result]
    if style:find('caption', 1, true) and previous and only_images(previous)
       and pandoc.utils.stringify(b):match('^[Ff]igure%s+%d') then
      result:remove(#result)
      result:insert(new_figure({previous}, b.content))
    else
      result:insert(b)
    end
  end
  return result
end

return {
  {Figure = function(f)
     if #f.caption.long == 0 then return f.content end
     return new_figure(f.content, f.caption.long, f.attr)
   end,
   Table = function(t)
     if #t.caption.long == 0 then return nil end
     tbl = tbl + 1
     if t.identifier == '' then t.identifier = 'tbl-import-' .. tbl end
     t.caption.long = strip_label(caption_blocks(t.caption.long))
     return t
   end},
  {Blocks = join_caption}
}
