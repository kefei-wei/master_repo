-- Ordinary paragraphs already use the reference document's body style.
-- Remove only style-only Body Text divs, without discarding other attributes.
return {{
  traverse = 'topdown',
  Div = function(div)
    local style = div.attributes['custom-style']
    if not style then return nil end

    -- Within another explicit style, Body Text may reset inherited formatting.
    -- Leave that entire subtree intact, including footnotes and table cells.
    if style ~= 'Body Text' then return div, false end
    if div.identifier ~= '' or #div.classes > 0 then return nil end
    for key, _ in pairs(div.attributes) do
      if key ~= 'custom-style' then return nil end
    end
    return div.content
  end
}}
