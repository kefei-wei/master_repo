-- Run after Quarto has generated numbered captions. Normalize its DOCX
-- float wrappers to native paragraphs so the Word reference controls style.
-- This handles content by type and applies equally to newly authored content.
if not FORMAT:match('docx') then return {} end
local function is_caption(p)
  for _, inline in ipairs(p.content or {}) do
    if inline.t == 'RawInline' and inline.format == 'openxml'
       and inline.text:find('ImageCaption', 1, true) then return true end
  end
  return false
end

local function unwrap_float(t)
  if #t.head.rows ~= 0 or #t.bodies ~= 1 or #t.bodies[1].body ~= 1 then return nil end
  local row = t.bodies[1].body[1]
  if #row.cells ~= 1 then return nil end
  local found = false
  pandoc.Pandoc(row.cells[1].contents):walk({Para=function(p)
    if is_caption(p) then found = true end
  end})
  if found then return row.cells[1].contents end
end

local function style_caption(p)
  if not is_caption(p) then
    local image = false
    pandoc.Para(p.content):walk({Image=function() image = true end})
    if not image then return nil end
    local contents = p.content:filter(function(i)
      return not (i.t == 'RawInline' and i.format == 'openxml' and i.text:find('<w:pPr>',1,true))
    end)
    return pandoc.Div({pandoc.Para(contents)}, pandoc.Attr('',{}, {['custom-style']='Captioned Figure'}))
  end
  local contents = p.content:filter(function(i)
    return not (i.t == 'RawInline' and i.format == 'openxml' and i.text:find('ImageCaption',1,true))
  end)
  local label = pandoc.utils.stringify(contents)
  local style = label:match('^Table') and 'Table Caption' or 'Image Caption'
  return pandoc.Div({pandoc.Para(contents)}, pandoc.Attr('',{}, {['custom-style']=style}))
end

return {{Table=unwrap_float}, {Para=style_caption, Plain=style_caption}}
