-- Browser output uses PNG previews for legacy WMF/EMF figures. The DOCX
-- writer keeps the source images and the QMD itself never changes.
if not FORMAT:match('html') then return {} end

function Image(el)
  local replacement = el.src:gsub('%.[wWeE][mM][fF]$', '-review.png')
  if replacement ~= el.src then el.src = replacement end
  return el
end
