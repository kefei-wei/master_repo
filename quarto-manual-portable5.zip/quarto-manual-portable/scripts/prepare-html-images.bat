@echo off
call "%~dp0run-python.bat" "%~dp0toolkit.py" images %*
exit /b %errorlevel%
