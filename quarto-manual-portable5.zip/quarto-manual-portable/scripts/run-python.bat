@echo off
setlocal
if defined TOOLKIT_PYTHON goto custom
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto launcher
python -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto python
echo ERROR: Python 3.10 or later is required. Install Python or set TOOLKIT_PYTHON to python.exe. 1>&2
exit /b 1
:custom
"%TOOLKIT_PYTHON%" %*
exit /b %errorlevel%
:launcher
py -3 %*
exit /b %errorlevel%
:python
python %*
exit /b %errorlevel%
