@echo off
call "%~dp0run-python.bat" "%~dp0toolkit.py" import %*
exit /b %errorlevel%
