@echo off
call "%~dp0run-python.bat" "%~dp0toolkit.py" build %*
exit /b %errorlevel%
