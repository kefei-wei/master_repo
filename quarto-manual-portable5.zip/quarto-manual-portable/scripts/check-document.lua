-- Run before Quarto's filters, including for existing imported projects.
function Image(image)
  local src = image.src
  if src:match('^https?://') or src:match('^data:') then return nil end
  local decoded = src:gsub('%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
  local file = io.open(decoded, 'rb')
  if not file then
    error('Missing image file: ' .. src .. '. Keep assets with the QMD and check the image path.')
  end
  file:close()
end
