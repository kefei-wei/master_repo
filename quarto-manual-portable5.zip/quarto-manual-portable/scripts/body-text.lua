-- Keep ordinary body paragraphs consistent, including after a heading.
-- Pandoc otherwise selects FirstParagraph, which may be missing or different
-- in an imported reference. Apply this only during Word export, after Quarto.
if not FORMAT:match('docx') then return {} end

return {{Pandoc = function(doc)
  for index, block in ipairs(doc.blocks) do
    if block.t == 'Para' then
      local ordinary = true
      block:walk({
        Image = function() ordinary = false end,
        RawInline = function() ordinary = false end
      })
      if ordinary then
        doc.blocks[index] = pandoc.Div({block},
          pandoc.Attr('', {}, {['custom-style'] = 'Body Text'}))
      end
    end
  end
  -- Explicit style divs, headings, lists, tables, figures and notes are intact.
  return doc
end}}
