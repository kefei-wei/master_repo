# Portable Word to Quarto toolkit (Python + batch)

Copy this entire folder to another Windows computer to import Word documents, edit Quarto Markdown (QMD), and export Word and standalone HTML review files. The prepared CONCLIFE manual is included.

**This version uses Python and `.bat` launchers. It contains no PowerShell scripts, never launches PowerShell, and needs no execution-policy changes.** If batch files are also restricted, use the direct Python commands below.

## Update an older toolkit

### Native Word captions and cross-references

Word builds now turn Quarto's figure/table caption numbers into real `SEQ Figure` and `SEQ Table` fields. Caption text, punctuation and formatting keep their existing styles. No new QMD markup is required. This applies to captions in the document body, including captions inside Quarto's layout tables and figures with several pictures sharing one caption.

To update an existing toolkit, back it up and replace its **entire `scripts/` folder** with this version. Keep your edited QMD, assets, configuration and reference document, then rebuild with `scripts\build.bat`. The native-field step runs automatically; `quarto render` alone does not run it.

Linked QMD cross-references in the document body, such as `@fig-setup` and `@tbl-materials`, also receive Word `REF` fields for their numbers. Keep Quarto's default `ref-hyperlink: true` setting under `crossref` for this feature. Manually typed prose such as "see Figure 1" and descriptive links remain literal. The included BA_SDD QMD uses literal references, so its build reports zero linked REF fields; the supplied manual uses QMD references and produces 17.

This version supports the toolkit's standard English figure/table labels and continuous Arabic numbering starting at 1 independently for each type. Chapter numbering, letter/Roman schemes and numbered subfigures require different Word field rules; the exporter stops with an explanation when it encounters unsupported numbered captions. HTML continues to use Quarto's numbering and contains no Word fields.

### Cleaner QMD paragraphs

New imports omit redundant `::: {custom-style="Body Text"}` wrappers. During Word export, the build applies the reference's `Body Text` style to ordinary top-level paragraphs, including those after headings. This avoids Pandoc's automatic `FirstParagraph` style, which can have different formatting or be missing in the reference. Special styles such as `Body Text Indent`, captions and footnotes are preserved, along with figure/table identifiers. A `Body Text` block inside a special style is retained because it can reset inherited formatting; blocks with additional attributes are also retained. HTML does not receive these Word style wrappers.

The included `projects/BA_SDD/BA_SDD.qmd` has had four redundant wrappers removed. Its text, pictures, tables and special styles are preserved. Updating the scripts affects future imports; it does not rewrite your existing edited QMD files. Keep your newer edits when updating an older toolkit.

### Table border correction

Word exports now preserve an explicit table style (such as `TableGrid`) when it exists in the reference. Tables without an available explicit style receive `Toolkit Data Table`, with thin black borders around and between cells. This applies to newly added tables and genuine one-cell tables too. Explicitly selected borderless table styles remain borderless.

Figure and caption layout tables receive a separate borderless style. Table captions are still formatted independently. HTML keeps its existing CSS appearance.

To update your existing toolkit, back it up and replace its **entire `scripts/` folder** with the one from this ZIP. Keep your QMD, assets and reference files. Build normally:

```bat
scripts\build.bat --project "projects\BA_SDD" --format docx
```

The first Word build updates the project's filter list if needed and saves the previous configuration as `_quarto.yml.before-table-fix`. It does not rewrite your QMD or reference document. New imports already include the correct filter order. Keep projects inside the toolkit folder so the filter paths remain portable.

**Use `build.bat` or `toolkit.py build` for Word export.** Running `quarto render` directly skips the Python table-finishing step. The build verifies that every QMD data table was processed, so a missing or incorrectly ordered filter produces an error.

This ZIP also includes the repaired `projects/BA_SDD` project and its Word output, recovered from the saved project ZIP used for diagnosis. Its QMD content is preserved, with the redundant body wrappers removed as described above. If you have newer edits elsewhere, keep those edits and update the scripts instead of replacing your project.

### September 28 correction: missing pictures and caption formatting

This version fixes two reproduced multi-picture conversion problems: Pandoc can drop a picture when Word stores several in one text run, and Quarto can drop a picture when several share one captioned paragraph. The importer splits a temporary copy's picture runs and writes separate picture blocks. Shared-caption pictures are stacked to avoid clipping in Word columns.

Imported figure/table captions now use Quarto identifiers and caption syntax. A Word output filter assigns `Image Caption` and `Table Caption` styles and avoids duplicate paragraph properties. If these styles are absent from the reference, the importer copies the original `Caption` style into them.

Before export, the build command checks local image paths and rejects stray `.caption`/`.captions` tokens being interpreted as text. It stops on Pandoc warnings and checks the output picture count. These checks cannot recover a picture that was already omitted from an older QMD import.

**Updating an existing edited project safely:**

1. Back up your entire current toolkit folder. Extract this version into a separate folder.
2. Copy your edited project folder, including QMD, `assets/`, `_quarto.yml` and `reference.docx`, into the new toolkit's `projects/` folder. Do not replace the QMD with a new import.
3. For projects made with the older generic importer, update their `_quarto.yml` filter list to:

   ```yaml
   filters:
     - ../../scripts/html-images.lua
     - ../../scripts/table-borders.lua
     - quarto
     - ../../scripts/docx-captions.lua
   ```

   Keep the remaining configuration. The prepared root `usermanual.qmd` already uses its own caption filter; keep its root configuration instead.
4. Build your edited QMD using the usual command. Correct any missing image paths the check reports. The current Word build converts caption numbers to native `SEQ` fields as described above.
5. If a picture was omitted during the old import, import the original DOCX into a **different project name**, such as `recovered-original`. Compare its picture blocks with your edited QMD. Copy the missing picture files and relevant blocks into your edited project without replacing your edited text.

For captions currently showing `.captions` as text, use valid Quarto syntax, as illustrated in section 3. Do not remove arbitrary text automatically. A captioned picture uses `![Caption](assets/picture.png){#fig-name}`; a table uses a separate `: Caption {#tbl-name}` line. Complex figures can use a fenced `::: {#fig-name}` block with one picture per paragraph and the caption as its final paragraph. Blank lines between the pictures matter.

The exact cause of literal `.captions` in a particular edited file requires inspecting that QMD. The tests reproduced image loss and incorrect Word caption styles, but the original local manual did not reproduce that literal-text symptom.

## 1. Set up the computer

Install your company's approved versions of:

- [Python for Windows](https://www.python.org/downloads/windows/), version 3.10 or later.
- [Quarto for Windows](https://quarto.org/docs/get-started/), which includes Pandoc.

Microsoft Word is not required for conversion. Use Word or another word processor to inspect the exported document's page layout.

Extract the ZIP, then open **Command Prompt** (Start menu: type `cmd`). These examples assume the extracted folder is `C:\Work\quarto-manual-portable`:

```bat
cd /d "C:\Work\quarto-manual-portable"
py -3 --version
quarto --version
```

If your Python command is `python` instead of `py -3`, substitute `python` in the examples. The batch launchers try `py -3` first, then `python`.

For HTML exports containing WMF/EMF pictures (including the supplied manual), install Pillow into that same Python environment:

```bat
py -3 -m pip install -r requirements.txt
```

Pillow is not needed for Word export, DOCX import, or HTML using only browser-compatible pictures such as PNG/JPEG. WMF/EMF previews use [Pillow's Windows renderer](https://pillow.readthedocs.io/en/stable/handbook/image-file-formats.html#wmf-emf). The requirement is Pillow 12.3 or later in the 12.x series. Without package-download access, have IT install it from an approved package source or wheel.

For Python that is not on PATH, set its executable for this Command Prompt session:

```bat
set "TOOLKIT_PYTHON=C:\Approved Python\python.exe"
"%TOOLKIT_PYTHON%" -m pip install -r requirements.txt
```

## 2. Convert another Word document to QMD

From the toolkit folder, replace the input path and run:

```bat
scripts\import-docx.bat "C:\Work\other-manual.docx"
```

The importer creates:

```text
projects/other-manual/
  other-manual.qmd   <- edit this file
  original.docx     <- unchanged source copy
  reference.docx    <- Word styles and page settings
  _quarto.yml       <- configuration
  review.css        <- HTML appearance
  assets/           <- extracted pictures, when present
```

The input file is unchanged. The importer retains many named styles as Markdown attributes. Recognized English `Figure 1.` and `Table 1.` prefixes become Quarto-managed numbering. Existing prose such as "see Figure 1" remains literal: replace it with `@fig-import-1` or the corresponding generated identifier if it must update after additions/deletions. The importer never overwrites an existing project. To import a revised file while preserving existing edits:

```bat
scripts\import-docx.bat "C:\Work\other-manual.docx" --project-name other-manual-v2
```

Names must start with a letter or number; use letters, numbers, hyphens, underscores or periods. Avoid consecutive periods, trailing periods and Windows reserved names. `original` and `reference` are reserved to protect the source and template. Spaces in input filenames become underscores in the default project name; the importer prints the resulting path.

## 3. Edit the QMD

Open `projects/other-manual/other-manual.qmd` in a text editor such as VS Code. You can add or remove sentences, paragraphs, sections, tables and pictures. Keep backups before large changes.

Use blank lines between paragraphs. Heading levels use `#`, `##`, and `###`:

```markdown
# New section

A paragraph with **bold** and *italic* text.

## Subsection

- First item
- Second item
```

For a new image, copy a PNG/JPEG to that project's `assets/` folder and insert:

```markdown
![New setup screen.](assets/new-setup.png){#fig-new-setup width="5in"}

See @fig-new-setup for the new screen.
```

For a simple table:

```markdown
| Material | Density |
|:---------|--------:|
| Concrete | 2350    |

: Material densities. {#tbl-densities}

See @tbl-densities for the values.
```

Use unique `fig-` and `tbl-` labels. When deleting content, also update references to it. Ordinary paragraphs do not need a `Body Text` wrapper. Keep matching `:::` markers around special styles and figure blocks such as `::: {#fig-import-1}`. New paragraphs use the reference's default paragraph styles; to reuse a special style, copy its wrapper from similar imported content, for example:

```markdown
::: {custom-style="Body Text Indent"}
This paragraph uses the named indented style from the Word reference.
:::
```

## 4. Export the edited QMD to Word

```bat
scripts\build.bat --project "projects\other-manual" --format docx
```

Open `projects/other-manual/output/other-manual.docx`. Inspect headings, tables, pictures and page breaks. Close the previous export in Word before rebuilding so it can be replaced. Builds replace the previous export in `output/`; save a separate copy to keep older versions.

To change formatting permanently, edit the **Word styles** in `reference.docx` and rebuild. Changes made only to the generated Word document will be replaced by the next build.

### Create lists of figures and tables in Word

1. Open the generated DOCX in Word. Press **Ctrl+A**, then **F9** to update fields. Repeat **F9** once if you have edited or moved captions in Word, so references that appear before their targets also receive the updated numbers. On some keyboards, use **Fn+F9**.
2. Place the cursor where the list of figures should appear.
3. Select **References > Insert Table of Figures**, choose **Figure** in **Caption label**, and select **OK**.
4. Move the cursor to a different location for the list of tables. Use **References > Insert Table of Figures** again, choose **Table** in **Caption label**, and select **OK**.
5. After changes, right-click each list and choose **Update Field > Update entire table**.

Both lists now use native caption fields; you do not need the style-based workaround. **Alt+F9** toggles the field-code view, where a caption number appears as `{ SEQ Figure \* ARABIC }` or `{ SEQ Table \* ARABIC }`. Leave these fields intact when editing in Word. The QMD remains the source for future builds: lists or edits added only in Word will be replaced on the next export, so save a separate Word working copy when needed.

If you delete a caption directly in Word, also remove or redirect references to it. Word correctly reports "Reference source not found" when a reference's target has been deleted.

## 5. Create an HTML review file

```bat
scripts\build.bat --project "projects\other-manual" --format html
```

Open `projects/other-manual/output/other-manual.html` in a browser. Images, scripts and CSS are embedded, so you can send this one HTML file to a reviewer. HTML is for reviewing content and navigation; it does not reproduce Word pagination.

WMF/EMF pictures under the project's `assets/` folder are converted to `*-review.png` previews automatically. Original vector pictures remain available for Word. Use PNG/JPEG for newly added pictures when possible.

## Use the supplied manual

Edit the root `usermanual.qmd`, then run:

```bat
scripts\build.bat --format docx
scripts\build.bat --format html
```

Outputs are `output/usermanual.docx` and `output/usermanual.html`. The unchanged source copy is **`original-usermanual.docx`**. Its distinct name prevents Quarto's temporary export file from overwriting it. The reference is `usermanual-reference.docx`.

The manual's Lua filters apply its chapter, section, table and caption styles. Other imported documents use their own reference file and do not receive the CONCLIFE-specific filters.

## Run Python directly (without batch files)

These commands perform the same operations from the toolkit folder:

```bat
py -3 scripts\toolkit.py import "C:\Work\other-manual.docx"
py -3 scripts\toolkit.py build --project "projects\other-manual" --format docx
py -3 scripts\toolkit.py build --project "projects\other-manual" --format html
```

Use `python` or a quoted full path to `python.exe` instead of `py -3` if needed.

## Options and troubleshooting

- **Quarto not found:** add `--quarto "C:\Approved Tools\Quarto\bin\quarto.exe"` to import or build. Standard Windows installations and PATH are checked.
- **Multiple QMD files:** add `--input-file "chapter.qmd"` to select one at the project root.
- **Paths:** quote paths containing spaces. `--project` is relative to the toolkit folder regardless of your current directory. Input DOCX paths are relative to your current directory; absolute paths are easiest.
- **Project already exists:** choose another `--project-name`. A failed import may leave a partial folder; inspect it before deleting it or retry under a new name.
- **Output filename exists beside QMD:** move or rename that file. Quarto temporarily creates output there before moving it into `output/`; the build script refuses collisions to protect source documents.
- **Pillow missing:** install `requirements.txt` using the interpreter the launcher selects, or set `TOOLKIT_PYTHON` explicitly. PNG/JPEG files do not need conversion.
- **Conversion error:** commands return a nonzero exit code and print the error. Check the referenced file path and Quarto message.
- **Help:** run `scripts\import-docx.bat --help` or `scripts\build.bat --help`.

## Script roles and folder contents

| File | Purpose |
|---|---|
| `scripts/import-docx.bat` | Launch Python's DOCX importer. |
| `scripts/build.bat` | Launch Python's Word/HTML exporter. |
| `scripts/prepare-html-images.bat` | Regenerate previews separately; accepts `--project`. HTML builds already do this. |
| `scripts/run-python.bat` | Choose Python, forward arguments and preserve exit codes. |
| `scripts/toolkit.py` | Import, export, path validation and WMF/EMF preview logic. |
| `scripts/table-borders.lua` | Identify actual data tables before Quarto creates layout tables; preserve their requested styles. |
| `scripts/docx_tables.py` | Restore Word table styles, supply a bordered fallback, and keep layout tables borderless. |
| `scripts/docx_fields.py` | Replace caption numbers with native SEQ fields and linked cross-reference numbers with REF fields, retaining formatting. |
| `scripts/docx_import.py` | Split multi-picture Word runs in a temporary copy; fill missing reference caption styles. |
| `scripts/import-captions.lua` | Write Quarto figure/table captions from imported DOCX structures. |
| `scripts/clean-body-text.lua` | Omit redundant Body Text wrappers during import, preserving special styles and attributed blocks. |
| `scripts/body-text.lua` | Apply Body Text to ordinary top-level Word paragraphs during export, including after headings; keep QMD and special styles intact. |
| `scripts/docx-captions.lua` | Apply native Word caption paragraph styles for generic imported projects. |
| `scripts/check-document.lua` | Reject missing image resources during rendering. |
| `scripts/html-images.lua` | Substitute PNG previews in HTML only. |
| `scripts/manual-style.lua` | Supplied manual's chapter, section, table and list styles. |
| `scripts/docx-layout.lua` | Supplied manual's Word picture and caption layout. |
| `requirements.txt` | Optional Pillow dependency for WMF/EMF HTML previews. |
| `_quarto.yml`, `styles/`, `assets/` | Manual configuration, CSS and pictures. |
| `projects/` | Imported document projects. |
| `output/` | Supplied manual's Word and HTML exports. |
| `tests/test_table_styles.py` | Standard-library regression tests for table styles and configuration upgrades. |
| `tests/test_caption_fields.py` | Regression tests for native fields, caption formatting, cross-references and unsupported numbering. |

Keep the whole toolkit together. Imported projects use the shared `scripts/html-images.lua` through a relative path. The earlier `convert.py` and `restore-format.py` used a fixed-block workflow that restricted additions/deletions; they are not required here.

## Style preservation and limits

A Word reference supplies named styles and page settings; it does not reproduce every direct-formatting or layout feature. Its body text is not inserted into the export. Complex floating layouts, text boxes, section breaks, embedded objects and tracked changes may need adjustment. Imported literal numbering may also need editing. Check an initial Word export before extensive editing of a new document.

The supplied manual has a customized reference and filters from the earlier verified conversion. Other documents receive a general conversion using their own styles. This supports structural editing but does not guarantee identical pagination after content changes.

## Validation

The Python/batch version is checked on Windows with Quarto 1.10.18 and Pillow 12.3.0: import of a second DOCX, Word and HTML exports, the supplied manual, picture conversion, argument handling and errors. The manual's exported Word body and style XML are compared with the previously verified export. HTML structure and embedded images are checked; inspect the HTML in your browser and the DOCX in Word for final visual review.

The September 28 regression checks additionally verify a fresh manual import with 9 pictures, 9 figure captions and 4 table captions; a two-picture shared-caption example; and an edited example with a deleted picture plus an added section, figure, table and cross-references. Missing-file and literal-caption-markup checks are exercised. The two compact Word regression outputs were rendered through Microsoft Word and visually inspected.

The table-border correction was verified on BA_SDD: all 5 data tables have borders, all 15 layout tables remain borderless, and all 10 pictures remain present. All 13 Word-rendered pages were inspected. Its QMD, original document, reference document and exported text were checked for preservation at that stage. Additional checks cover uncaptioned tables, one-cell tables, explicit bordered/borderless styles, nested tables, footnotes, new imports and HTML export.

The body-wrapper cleanup was checked by comparing the complete parsed QMD before and after: only the four intended wrappers changed. A fresh DOCX import produced the same cleaned QMD. Checks also confirmed that nested style resets, attributed blocks and literal code examples are preserved. Word and HTML builds passed; the Word output still has 13 pages, 10 pictures, 5 styled data tables and 15 borderless layout tables. Every rendered Word page was inspected. Ordinary top-level paragraphs now consistently use `Body Text`; special styles, table structure, media, notes, source DOCX and reference DOCX are unchanged. In the prepared manual, `Body Text` and `First Paragraph` have identical formatting, so this export change preserves its appearance.

The native-caption update was verified in Microsoft Word itself: its normal Table of Figures command found all 10 figures and 5 tables in BA_SDD, and all 9 figures and 4 tables in the supplied manual. Field updates retained correct numbering and all 17 manual cross-references. Separate tests deleted captions in Word and confirmed renumbering of the remaining captions and references; QMD edits added/deleted figures, tables and a section, including a shared-caption multi-picture figure. All 13 BA_SDD pages and 18 supplied-manual pages were rendered and inspected. HTML export retained its 10 embedded pictures and 5 tables. The 12 automated tests cover caption fields, formatting, forward references, split numbers, idempotence, unsupported numbering and the existing table-border behavior.

To run the standard-library tests from the toolkit folder:

```bat
py -3 -m unittest discover -s tests -v
```
