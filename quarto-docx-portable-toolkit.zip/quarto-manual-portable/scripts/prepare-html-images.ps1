param([string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Stop'
$assets = Join-Path $ProjectRoot 'assets'
if (-not (Test-Path -LiteralPath $assets)) { return }
Add-Type -AssemblyName System.Drawing
$vectors = @(Get-ChildItem -LiteralPath $assets -Recurse -File | Where-Object { $_.Extension.ToLowerInvariant() -in @('.wmf', '.emf') })
foreach ($source in $vectors) {
    $target = Join-Path $source.DirectoryName ($source.BaseName + '-review.png')
    $metafile = $null
    $bitmap = $null
    $graphics = $null
    try {
        $metafile = [System.Drawing.Imaging.Metafile]::new($source.FullName)
        $scale = [Math]::Min(2.5, 2048.0 / [Math]::Max($metafile.Width, $metafile.Height))
        $width = [Math]::Max(1, [int][Math]::Round($metafile.Width * $scale))
        $height = [Math]::Max(1, [int][Math]::Round($metafile.Height * $scale))
        $bitmap = [System.Drawing.Bitmap]::new($width, $height)
        $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
        $graphics.Clear([System.Drawing.Color]::White)
        $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $graphics.DrawImage($metafile, [System.Drawing.Rectangle]::new(0, 0, $width, $height))
        $bitmap.Save($target, [System.Drawing.Imaging.ImageFormat]::Png)
    } finally {
        if ($graphics) { $graphics.Dispose() }
        if ($bitmap) { $bitmap.Dispose() }
        if ($metafile) { $metafile.Dispose() }
    }
}
