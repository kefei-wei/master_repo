param(
    [Parameter(Mandatory = $true)][string]$InputDocx,
    [string]$ProjectName,
    [string]$Quarto
)
$ErrorActionPreference = 'Stop'
$bundle = Split-Path -Parent $PSScriptRoot
$inputPath = (Resolve-Path -LiteralPath $InputDocx).Path
if ([System.IO.Path]::GetExtension($inputPath).ToLowerInvariant() -ne '.docx') {
    throw 'InputDocx must be a .docx file.'
}
if (-not $ProjectName) {
    $ProjectName = [System.IO.Path]::GetFileNameWithoutExtension($inputPath) -replace '[^A-Za-z0-9._-]', '_'
}
if ($ProjectName -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]*$' -or $ProjectName -match '\.\.') {
    throw 'ProjectName must use letters, numbers, periods, underscores, or hyphens and cannot contain ..'
}
$target = Join-Path (Join-Path $bundle 'projects') $ProjectName
if (Test-Path -LiteralPath $target) { throw "Project already exists: $target. Choose another -ProjectName to preserve your edits." }

if (-not $Quarto) {
    $candidates = @(
        (Join-Path $env:ProgramFiles 'Quarto\bin\quarto.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Quarto\bin\quarto.exe')
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) { $Quarto = $candidate; break }
    }
    if (-not $Quarto) { $Quarto = (Get-Command quarto -ErrorAction Stop).Source }
}
$pandoc = Join-Path (Split-Path -Parent $Quarto) 'tools\pandoc.exe'
if (-not (Test-Path -LiteralPath $pandoc)) { throw "Cannot find Pandoc bundled with Quarto: $pandoc" }

New-Item -ItemType Directory -Force -Path $target | Out-Null
Copy-Item -LiteralPath $inputPath -Destination (Join-Path $target 'original.docx')
Copy-Item -LiteralPath $inputPath -Destination (Join-Path $target 'reference.docx')
Copy-Item -LiteralPath (Join-Path $bundle 'styles\review.css') -Destination (Join-Path $target 'review.css')
$qmd = $ProjectName + '.qmd'
$config = @'
project:
  type: default
  output-dir: output
format:
  docx:
    reference-doc: reference.docx
    toc: false
    number-sections: false
  html:
    embed-resources: true
    toc: true
    css: review.css
filters:
  - ../../scripts/html-images.lua
  - quarto
execute:
  enabled: false
'@
[System.IO.File]::WriteAllText((Join-Path $target '_quarto.yml'), $config, [System.Text.UTF8Encoding]::new($false))
Push-Location $target
try {
    & $pandoc $inputPath -f docx+styles -t markdown+fenced_divs+bracketed_spans --wrap=none --extract-media=assets -o $qmd
    if ($LASTEXITCODE -ne 0) { throw 'Pandoc DOCX import failed.' }
} finally { Pop-Location }
Write-Output "Created $target"
Write-Output "Edit $qmd, then run: .\scripts\build.ps1 -Project 'projects\$ProjectName' -Format docx"
