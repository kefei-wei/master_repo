param(
    [string]$Project = '.',
    [string]$InputFile,
    [ValidateSet('docx', 'html')][string]$Format = 'docx',
    [string]$Quarto
)
$ErrorActionPreference = 'Stop'
$bundle = Split-Path -Parent $PSScriptRoot
$projectPath = if ([System.IO.Path]::IsPathRooted($Project)) { $Project } else { Join-Path $bundle $Project }
$projectPath = (Resolve-Path -LiteralPath $projectPath).Path

if (-not $Quarto) {
    $candidates = @(
        (Join-Path $env:ProgramFiles 'Quarto\bin\quarto.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Quarto\bin\quarto.exe')
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) { $Quarto = $candidate; break }
    }
    if (-not $Quarto) { $Quarto = (Get-Command quarto -ErrorAction Stop).Source }
}
if (-not $InputFile) {
    $sources = @(Get-ChildItem -LiteralPath $projectPath -File -Filter '*.qmd')
    if ($sources.Count -ne 1) { throw "Expected one QMD in $projectPath; pass -InputFile explicitly." }
    $InputFile = $sources[0].Name
}
$inputPath = (Resolve-Path -LiteralPath (Join-Path $projectPath $InputFile)).Path
if ([System.IO.Path]::GetDirectoryName($inputPath) -ne $projectPath) {
    throw 'InputFile must be a QMD in the selected project folder.'
}
if ($Format -eq 'html') {
    & (Join-Path $PSScriptRoot 'prepare-html-images.ps1') -ProjectRoot $projectPath
}
Push-Location $projectPath
try {
    & $Quarto render $InputFile --to $Format
    if ($LASTEXITCODE -ne 0) { throw "Quarto $Format render failed." }
} finally { Pop-Location }
Write-Output (Join-Path $projectPath ('output\' + [System.IO.Path]::GetFileNameWithoutExtension($InputFile) + '.' + $Format))
