# Portable Word to Quarto toolkit

This folder can be copied or zipped and moved to another **Windows** computer. All conversion and build scripts are together in `scripts/`. It includes the prepared CONCLIFE manual as a working example and can create a separate Quarto project from another `.docx` file.

## What to install on the other computer

Install [Quarto](https://quarto.org/docs/get-started/) for Windows. Quarto supplies the Pandoc converter used by the import script. PowerShell is included with Windows. Python and Microsoft Word are **not** required for routine import, editing, or export. Open the final DOCX in Word or another word processor to check its page layout.

Keep the extracted folder together. Do not move only `scripts/`: the manual, styles, and extracted images use relative paths within the folder.

## Folder contents

| Path | Purpose |
|---|---|
| `scripts/import-docx.ps1` | Import **another** DOCX into its own project under `projects/`. |
| `scripts/build.ps1` | Export a QMD project to DOCX or HTML. |
| `scripts/prepare-html-images.ps1` | Convert extracted WMF/EMF images to PNG previews for browsers. Called by `build.ps1` for HTML. |
| `scripts/html-images.lua` | Select those PNG previews only in HTML. |
| `scripts/manual-style.lua` | Original CONCLIFE manual's chapter, section, table, and list styling. |
| `scripts/docx-layout.lua` | Original CONCLIFE manual's Word caption and picture styling. |
| `usermanual.docx` | Unchanged original manual. |
| `usermanual.qmd` | Already converted, editable manual. |
| `usermanual-reference.docx` | Word reference for the prepared manual. |
| `_quarto.yml` | Quarto configuration for the prepared manual. |
| `assets/`, `styles/` | Pictures and HTML review stylesheet. |
| `output/` | Ready-made Word and standalone HTML examples. Rebuilt after editing. |
| `projects/` | A separate subfolder is created here for every other imported DOCX. |

The older `convert.py` and `restore-format.py` belong to the earlier exact-layout workflow. They depend on fixed original block IDs and reject added or deleted sections. They are intentionally not part of this editable toolkit.

## Use the already converted CONCLIFE manual

1. Open `usermanual.qmd` and edit the content. A `#` heading starts a chapter; `##` starts a numbered section. Add or delete paragraphs, tables, and image lines as needed. Keep `assets/` with the QMD.
2. Open PowerShell and change into this folder. For example, if you extracted it to `C:\Work\quarto-manual-portable`:

   ```powershell
   Set-Location 'C:\Work\quarto-manual-portable'
   ```

3. Build the Word document:

   ```powershell
   .\scripts\build.ps1 -Format docx
   ```

   Open `output/usermanual.docx`.

4. Build a single HTML file for browser review:

   ```powershell
   .\scripts\build.ps1 -Format html
   ```

   Open `output/usermanual.html` in a browser. The images and stylesheet are embedded in that file, so you can send the HTML file by itself to a reviewer. Its clickable table of contents and figure/table references help with navigation. The HTML view is for content review; Word decides the final page breaks.

To add a figure in the prepared manual, place a PNG or JPEG in `assets/` and add a line such as:

```markdown
![New setup screen.](assets/new-setup.png){#fig-new-setup width="5in"}

See @fig-new-setup for the new screen.
```

To add a table:

```markdown
| Material | Density |
|:---------|--------:|
| Concrete | 2350    |

: Material densities. {#tbl-densities}

See @tbl-densities for the values.
```

Use a unique `fig-` or `tbl-` label for every figure or table you want to cross-reference. Remove or update references when you delete their target.

## Convert another DOCX to QMD

1. From PowerShell in the extracted toolkit folder, run the importer with an absolute path to the Word file:

   ```powershell
   .\scripts\import-docx.ps1 -InputDocx 'C:\Work\other-manual.docx'
   ```

   The importer uses Quarto's bundled Pandoc to read the DOCX with its named styles and extract its pictures. It creates `projects/other-manual/other-manual.qmd`, a copy of the source called `original.docx`, and a `reference.docx` used for later Word exports. It also creates the Quarto configuration in that project. The source file at `C:\Work\other-manual.docx` is not changed.

2. Open `projects/other-manual/other-manual.qmd` and edit it. Separate paragraphs with blank lines. Use `#`, `##`, and `###` for heading levels. A new picture can be written as `![Caption](assets/new-picture.png){#fig-new-picture}` after placing the file in that project's `assets/` folder. Simple tables can use the pipe-table syntax shown above.

3. Export that QMD back to Word:

   ```powershell
   .\scripts\build.ps1 -Project 'projects\other-manual' -Format docx
   ```

   Open `projects/other-manual/output/other-manual.docx`.

4. Make a browser review copy:

   ```powershell
   .\scripts\build.ps1 -Project 'projects\other-manual' -Format html
   ```

   Open `projects/other-manual/output/other-manual.html`.

The importer never overwrites an existing project. To import a revised Word file while keeping your edits, choose a new name, for example:

```powershell
.\scripts\import-docx.ps1 -InputDocx 'C:\Work\other-manual.docx' -ProjectName 'other-manual-v2'
```

If Quarto is installed in a nonstandard location, pass its executable path to `-Quarto` on the import or build command. `build.ps1 -InputFile name.qmd` selects a specific QMD when a project has more than one.

## How the styles work

For the prepared CONCLIFE manual, `usermanual-reference.docx` and the two manual Lua filters apply the tested font, heading, caption, table, and page styles. New content of the same type receives those styles on the next Word export.

For a different DOCX, the importer copies that file to `reference.docx`, which Quarto uses for named Word styles and page settings. The imported QMD retains content and many named styles. Word features that Markdown cannot represent exactly—such as complex floating layouts, text boxes, some section breaks, tracked changes, and embedded objects—may need manual adjustment after import. Check the first Word export before making large edits. HTML is a content review view and uses the toolkit's browser stylesheet, not the Word reference.

To change the Word appearance of a project, edit the **styles** in its `reference.docx`, save it, and rebuild. Directly changing only the generated DOCX will be replaced by the next build.

## Tested here

This bundle rendered the prepared manual to DOCX and a self-contained HTML file. A second document, `Sdd_Sample.docx`, was imported to a new QMD project and exported to both formats. The prepared manual's new Word document has the same `document.xml` and `styles.xml` as the previously verified export. The HTML review file contains all nine manual images as embedded PNG data and has no broken internal links or external script/style files. Visual browser inspection was unavailable in this session after the desktop browser controller stopped; open the HTML file locally for final visual review.
