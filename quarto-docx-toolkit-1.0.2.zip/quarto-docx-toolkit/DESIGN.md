# Word–Quarto toolkit: design and code guide

Release 1.1.0. This document explains the implementation shipped beside it. [README.md](README.md) is the operational guide for importing, editing and building documents.

## 1. Design overview

The toolkit separates editable content, reusable formatting and generated output:

- **Content:** a QMD file contains text, headings, tables, image paths, captions and cross-reference identifiers.
- **Word formatting:** `reference.docx` supplies Word styles and page settings. Special QMD style attributes select named styles in this reference.
- **HTML formatting:** the project's `review.css` supplies browser styles.
- **Generated output:** `output/<name>.docx` and `output/<name>.html` are rebuilt from the QMD. Changes made only to an export do not feed back into the QMD.

The conversion does not depend on a paragraph's old position in the original Word document. It processes the current QMD structure on each build. That is why adding or deleting sections, sentences, pictures and tables can work without maintaining a mapping to the original document's paragraph numbers.

Quarto and Pandoc perform the general document conversion. The toolkit adds targeted handling for picture preservation, editable captions, named paragraph styles, table borders and native Word fields.

### Terms used in the code

| Term | Meaning here |
|---|---|
| AST / document tree | Pandoc's structured representation of a document: paragraphs, images, tables, headings, and other nodes. |
| Lua filter | A small program that changes selected nodes during Pandoc/Quarto conversion. |
| `Div` / `Span` | A block-level / inline container carrying attributes such as `custom-style`. |
| Word run (`w:r`) | A group of content within a paragraph that shares text formatting. One run can contain multiple objects. |
| WordprocessingML | The XML used for Word document content and styles inside a DOCX ZIP package. |
| Data table | A table authored in the QMD, including a genuine one-cell table. |
| Layout table | A table generated internally by Quarto/Pandoc to arrange a figure or caption. It should normally have no visible borders. |
| Field | An instruction Word can calculate, with a cached displayed result. `SEQ` numbers captions; `REF` reads a bookmark's result. |
| Bookmark | A named range in Word, represented by separate start/end markers. It is not necessarily an XML parent container. |

### Execution flow

```mermaid
flowchart TD
    A[Source DOCX] --> B[Python: create project and prepare temporary DOCX]
    B --> C[Pandoc plus import Lua filters]
    C --> D[Editable QMD and extracted pictures]
    D --> E[Python: validate QMD]
    E --> F[Quarto plus export Lua filters]
    R[reference.docx] --> F
    F --> G[Generated DOCX]
    G --> H[Python: finish table styles]
    H --> I[Python: create SEQ and REF fields]
    I --> J[Verify picture count and report Word output]
    E --> K[Prepare WMF/EMF previews if needed]
    K --> L[Quarto HTML render]
    S[Project review.css] --> L
    L --> M[Standalone HTML review file]
```

The batch files are convenience entry points. They select Python and forward arguments; the conversion logic lives in Python and Lua. Python passes argument lists to `subprocess.run` rather than constructing shell command strings for Quarto/Pandoc.

## 2. Files and dependencies

The release contains 18 files: 14 runtime scripts, one CSS file, one dependency list and two documentation files. It does not require a bundled sample project.

| File | Role | When used |
|---|---|---|
| `README.md` | User setup, editing, build and troubleshooting instructions | Read by users |
| `DESIGN.md` | Architecture and file/function explanation | Read by users and maintainers |
| `requirements.txt` | Optional Pillow dependency | Installing WMF/EMF preview support |
| `scripts/import-docx.bat` | Import launcher | DOCX → QMD |
| `scripts/build.bat` | Export launcher | QMD → Word or HTML |
| `scripts/run-python.bat` | Interpreter selection and argument forwarding | Both launchers; optional dependency installation |
| `scripts/toolkit.py` | Command-line interface and conversion orchestration | Every toolkit command |
| `scripts/docx_import.py` | Prepare reference styles and preserve multi-picture runs | Import |
| `scripts/docx_tables.py` | Finish Word data-table and layout-table styles | Word export |
| `scripts/docx_fields.py` | Create native Word caption and reference fields | Word export |
| `scripts/import-captions.lua` | Convert imported captions into Quarto structure | Import |
| `scripts/clean-body-text.lua` | Remove redundant ordinary-paragraph style wrappers | Import |
| `scripts/table-borders.lua` | Mark real data tables and preserve requested style names | Word export, before Quarto's core pass |
| `scripts/docx-captions.lua` | Apply correct caption paragraph styles | Word export, after Quarto's core pass |
| `scripts/body-text.lua` | Apply `Body Text` to ordinary top-level paragraphs | Word export, after Quarto's core pass |
| `scripts/check-document.lua` | Check local image resources during rendering | Word and HTML export |
| `scripts/html-images.lua` | Substitute browser-compatible vector previews | HTML export |
| `styles/review.css` | Master HTML stylesheet copied into new projects | Import; project copy used by HTML export |

`toolkit.py` imports the three `docx_*.py` helpers. `docx_fields.py` also imports the namespace and two XML helpers from `docx_tables.py`. The Python modules use only the standard library, except for the optional, lazily imported Pillow preview renderer. Quarto supplies Pandoc and the Lua runtime; users do not install Lua separately.

## 3. Import design: DOCX → QMD

The import command follows this sequence:

1. Validate the source DOCX path and project name. Resolve an optional `--project-dir` from the caller's directory and reject collisions with project files or staging/export paths.
2. Locate Quarto and its bundled Pandoc.
3. Create the exact requested directory, or `toolkit/projects/<name>/` when no destination is supplied, and copy the source to `original.docx`. A requested directory may contain unrelated files, which are preserved.
4. Create `reference.docx`, filling missing image/table caption styles from the source's `Caption` style when available.
5. Write `_quarto.yml` and copy the master HTML stylesheet into the project.
6. Prepare a temporary DOCX whose multi-picture runs have been separated. The source and reference are not normalized this way.
7. Run Pandoc with the caption-import filter followed by the Body Text cleanup filter. Extract pictures under `assets` and write `<name>.qmd`.

The relevant Pandoc settings are:

| Setting | Reason |
|---|---|
| `-f docx+styles` | Expose named Word styles to the import filters and Markdown writer. |
| `-t markdown+fenced_divs+bracketed_spans-simple_tables-multiline_tables` | Retain block/inline style attributes and avoid two less convenient table syntaxes. |
| `--wrap=none` | Avoid arbitrary source-line wrapping in the editable QMD. |
| `--extract-media=assets` | Put extracted pictures with the project and use portable relative paths. |

Each input gets its own reference document. The release therefore needs no global sample reference DOCX. A reference supplies formatting; its body content is not a skeleton into which edited paragraphs are inserted.

With `--project-dir module/xxxx/design`, the default QMD basename is the destination folder name (`design.qmd`). `--project-name SDD` overrides only the basename (`design/SDD.qmd`), without appending another directory. Without `--project-dir`, the source DOCX basename remains the default project name and the old toolkit-local destination remains available. Existing default project directories are still rejected.

## 4. Export design: QMD → Word or HTML

### Common preflight

The builder resolves the project directory, checks `_quarto.yml`, and selects the only root-level QMD or the file named by `--input-file`. It rejects a same-basename output beside that QMD because Quarto uses that location temporarily before moving the export into `output`.

Pandoc parses the QMD into JSON. The toolkit counts actual image/table nodes, checks local image paths and rejects stray caption tokens interpreted as prose. Literal code examples are excluded from these checks. HTTP, HTTPS and data URLs are left to the renderer; preflight does not test their network availability.

For either output format, the builder refreshes the three built-in filter paths in the project's top-level filter list to point to the toolkit being executed. This allows projects and toolkit installations to move independently. A changed configuration is backed up once as `_quarto.yml.before-toolkit-paths`; QMD, reference and assets are not rewritten by this operation.

### Word path

1. Confirm that `table-borders.lua` runs before the explicit `quarto` filter entry. Upgrade older toolkit configurations if the filter is missing, saving a backup once.
2. Render through Quarto with warnings treated as failures.
3. Finish table styles in the generated DOCX and verify the number of marked data tables.
4. Replace caption numbers with native `SEQ` fields and eligible linked reference numbers with `REF` fields.
5. Count picture placements in the main document, footnotes and endnotes. Fail if fewer placements exist than image nodes in the QMD.

The Python finishing steps are why a bare `quarto render` is not equivalent to `build.bat`.

### HTML path

1. Generate PNG previews for WMF/EMF files beneath `assets`, if any.
2. Render through Quarto. The HTML image filter selects the previews in the in-memory tree.
3. Use the project's CSS and `embed-resources: true` to produce the standalone review output.

Word-specific filters return without changes for HTML. Python does not apply the DOCX table/field finishers to HTML. The original QMD image paths stay unchanged, so Word continues to use the original pictures.

### Filter order is part of the design

New projects contain this ordered list, with each path computed from the project directory to the toolkit's `scripts` directory (the placeholder below is illustrative):

```yaml
filters:
  - "<computed-scripts-path>/html-images.lua"
  - "<computed-scripts-path>/table-borders.lua"
  - quarto
  - "<computed-scripts-path>/docx-captions.lua"
```

`toolkit.py` additionally passes `check-document.lua` and `body-text.lua` as command-line filters after Quarto's core pass. The explicit `quarto` entry separates filters that need the original content from those that need Quarto's generated caption structure. Each format-specific filter checks `FORMAT` before doing work.

Do not move the table marker filter after Quarto: at that point generated layout tables could be confused with authored data tables. Caption-style repair has the opposite requirement: it needs the captions Quarto has already generated.

## 5. Detailed file and function guide

### 5.1 `README.md`

The operating manual: installation, DOCX import, QMD editing examples, Word/HTML commands, native caption updates in Word, project migration and troubleshooting. It also identifies supported numbering and layout limits. It is not read by the program.

### 5.2 `DESIGN.md`

This technical guide explains data flow, dependencies, individual functions and implementation constraints. It is not read by the program. Update it when changing runtime behavior or the file inventory.

### 5.3 `requirements.txt`

Declares `Pillow>=12.3,<13`. Pillow supplies the Windows WMF/EMF renderer used for HTML previews. The version range keeps installations within the tested major series; it does not pin an exact patch version. DOCX import/export and HTML using PNG/JPEG do not need it. Python, Quarto and Pandoc are not installed by this file.

### 5.4 `scripts/import-docx.bat`

Calls `run-python.bat`, passing the adjacent `toolkit.py`, the `import` subcommand and all user arguments. `%~dp0` resolves the launcher's own directory, so script discovery is independent of the current working directory. `%*` forwards the arguments. `call` allows this batch file to resume after the nested launcher returns, and `exit /b %errorlevel%` propagates its status.

Input: a DOCX path and optional project directory, project name and Quarto path. Output: the Python command's console output and exit status. It does not itself modify document content or change the caller's working directory.

### 5.5 `scripts/build.bat`

Uses the same launcher pattern, but supplies the `build` subcommand. Word and HTML exports share this file; `--format` selects the output. It propagates errors so scripts that call the toolkit can detect a failed build.

### 5.6 `scripts/run-python.bat`

Chooses the interpreter in this order:

1. `TOOLKIT_PYTHON`, if explicitly set. This override is used directly; the launcher does not probe its version.
2. `py -3`, if a quiet probe confirms Python 3.10 or later.
3. `python` on PATH, if the same version check succeeds.

If no default interpreter qualifies, it prints an error and exits with code 1. Interpreter branches forward the requested Python script/module and arguments, then immediately return Python's exit status. `setlocal` limits environment changes to the invocation. No PowerShell process is involved.

### 5.7 `scripts/toolkit.py`

This module coordinates the whole tool. `BUNDLE` is derived from its own path. `CONFIG` is the project YAML template with filter-path placeholders: output goes to `output`, Word uses `reference.docx`, HTML uses embedded resources and `review.css`, and code execution is disabled. Word TOC/section numbering are off; the HTML TOC is on by default.

| Function | Responsibility and result |
|---|---|
| `find_quarto(explicit)` | Locate an explicit executable, common Windows installation or PATH entry; return its absolute `Path` or raise a useful error. |
| `project_path(value)` | Resolve an absolute project path or anchor a relative one to the caller's current directory. |
| `filter_path(project, filename)` | Compute a path from the project to a bundled Lua filter, using an absolute forward-slash path when Windows drives differ. |
| `project_config(project)` | Substitute computed, JSON-quoted filter paths into the YAML template; quoting handles spaces and YAML-sensitive characters. |
| `refresh_filter_paths(project)` | Rebind the three built-in scalar filter entries after relocation while preserving order, comments and other configuration; back up changed configuration once. |
| `import_docx(args)` | Validate names, create project files, prepare temporary DOCX, run Pandoc and report the new QMD. |
| `walk_nodes(value)` | Recursively yield dictionaries from Pandoc JSON while avoiding descent into literal code nodes. |
| `check_qmd(source, quarto)` | Parse QMD, validate local images and caption tokens, return `(image_count, table_count)`. |
| `prepare_images(project)` | Find WMF/EMF files under `assets` and write `*-review.png` siblings. Return without loading Pillow when there are no such files. |
| `ensure_table_filter(project)` | Verify filter ordering or insert a missing table filter while saving `_quarto.yml.before-table-fix` once. |
| `build(args)` | Perform preflight, render, run the relevant finishing steps, verify picture counts and report the output location. |
| `main()` | Define CLI commands, dispatch them, and convert expected operational errors to an error message and exit code 1. |

`prepare_images` uses Pillow's Windows renderer, increases rendering resolution with a scale calculation bounded using the source dimensions, converts to RGB and saves PNG. It processes all WMF/EMF files under `assets`, including ones no longer referenced by the QMD. It refreshes previews on each HTML build. The separate `images --project ...` command exposes the same operation for troubleshooting.

The filter-upgrade function edits YAML as text to preserve unrelated settings and comments without adding a YAML library. It handles the toolkit's simple filter-list form, requires exactly one explicit `quarto` entry, and rejects duplicate/misordered table filter entries instead of guessing.

The path-refresh function also uses targeted text editing. It operates only on scalar entries in the top-level `filters` sequence. It understands plain, single-quoted and JSON-compatible double-quoted paths, and preserves trailing comments. It recognizes the reserved basenames `html-images.lua`, `table-borders.lua` and `docx-captions.lua`. Other filters, nested mappings and format-specific filter lists are left alone. Use different filenames for custom filters. Complex custom YAML requires explicit path maintenance rather than automatic rewriting.

All supplied input and project paths are now relative to the caller's current directory unless absolute. This deliberately changes the `--project` behavior from 1.0.x, where relative paths started at `BUNDLE`. There is no fallback search that might silently choose the wrong project when the same relative name exists in both places. Commands already run from the toolkit directory retain their usual result.

The build expects output at `<project>/output/<QMD-stem>.docx` or `.html`. Keep the generated output settings for finishing and verification. `--project` defaults to the current directory, so running from `module/xxxx/design` needs no project argument. Scripts and the Word/HTML project do not need to share a directory or drive.

### 5.8 `scripts/docx_import.py`

Prepares two different DOCX copies during import. It edits ZIP/XML directly, without Microsoft Word or the `python-docx` package.

**`copy_caption_styles(source, destination)`** copies the input into `reference.docx`. In `word/styles.xml`, it looks for the source `Caption` style and clones it as `ImageCaption` / `Image Caption` and `TableCaption` / `Table Caption` only if those style IDs are missing. Existing styles win. If there is no source `Caption` style, no substitute is synthesized. All other ZIP member data is copied unchanged.

**`split_picture_runs(source, destination)`** creates the temporary import copy. It examines runs in `word/document.xml`; if a run contains at least two `drawing`, `pict` or `object` children, it gives each content child a separate run, preserving order and copying the original run properties. Adjacent text is retained too. The returned integer counts original runs split, not pictures.

This prevents the reproduced Pandoc problem where only the first picture in a multi-picture run survived. It does not normalize headers, footers or note parts. The XML DOM preserves namespace prefixes and declarations, including prefixes referenced indirectly by compatibility attributes.

### 5.9 `scripts/docx_tables.py`

Works with `table-borders.lua` to distinguish data tables from layout tables after rendering. It changes table style references and adds fallback styles to the generated output, leaving the source QMD and reference alone.

| Function | Responsibility |
|---|---|
| `children(element, local)` | Return immediate WordprocessingML children of the requested name; avoid selecting nested-table properties accidentally. |
| `element(doc, tag, **attrs)` | Create a `w:` element and namespace-qualified attributes. Also reused by the field module. |
| `set_style(table, name)` | Ensure one `tblStyle` inside `tblPr`, retaining other table properties. |
| `ensure_style(styles, name, bordered)` | Keep an existing compatible toolkit table style or create a bordered/borderless fallback. |
| `comments(node)` | Recursively yield XML comments from snapshots safe for marker removal. |
| `finish_tables(path, expected_tables)` | Consume table markers, apply styles, validate counts and replace the output ZIP. Return `(data_count, layout_count)`. |

The marker protocol is `<!--toolkit-data-table:HEX-->`. `HEX` is the requested style name encoded as UTF-8 bytes in hexadecimal; an empty name has an empty suffix. The Lua writer and Python reader must agree on this format.

For each marker, Python finds the **nearest enclosing table**, which handles nested tables correctly. It resolves the requested style by internal ID or displayed name. If unavailable, it applies `ToolkitDataTable`, whose default six borders are black, single, 0.5 point (`sz=4`, measured in eighths of a point). An existing explicit borderless style is respected. Existing toolkit styles are preserved rather than reset.

Unmarked tables using Pandoc's `Table` style receive `ToolkitLayoutTable` with explicit `nil` borders. Independently styled raw OpenXML tables are left alone. Existing direct table formatting is retained; a style change is not a blanket removal of every possible direct override.

The helper processes `document.xml`, `footnotes.xml` and `endnotes.xml`. Marker count must match the preflight QMD table count before changes are written. A complete `.tables-tmp` ZIP is staged next to the output and replaces it only after successful construction. Untouched member data and ZIP metadata are retained.

Markers are consumed, so this helper is designed for one pass over a fresh Quarto render. Re-running it with the same positive expected count on an already-finished document will fail the marker check. A normal build renders fresh output first.

### 5.10 `scripts/docx_fields.py`

Converts rendered caption/reference numbers into fields Word can recalculate. It edits only `word/document.xml`; styles are read to identify captions but are not changed here. Captions inside layout tables are included because they are part of the main document XML.

| Function | Responsibility |
|---|---|
| `descendants(node, local)` | Snapshot matching WordprocessingML descendants. |
| `text(node)` | Read direct text-node children. |
| `visible_text(node)` | Concatenate displayed `w:t` text, excluding field instructions. |
| `instructions(node)` | Collect simple-field attributes and complex-field instruction text to detect existing fields. |
| `text_run(run, value)` | Clone run formatting and create replacement text with whitespace preserved. |
| `replace_number(container, start, end, instruction, bookmark)` | Replace a character range across direct runs with a field, optionally enclosed by a number-only bookmark. |
| `caption_bookmarks(document)` | Associate paragraphs with active Quarto bookmark ranges in document order. Its nested `visit` function performs the traversal. |
| `finish_fields(path)` | Identify captions, create `SEQ` fields/bookmarks, convert eligible links to `REF`, and atomically replace the output. Return Figure, Table and newly converted REF counts. |

Caption detection first checks the paragraph style ID or its displayed name (`Image Caption` / `Table Caption`). It then parses an English Figure/Fig./Table/Tbl. label and a number. Ordinary prose mentioning a figure is not a caption. Each kind must use continuous Arabic numbering from 1. Unsupported chapter/subfigure numbering stops conversion rather than producing fields with different numbering rules.

For example, the displayed caption `Figure 2: Measurement setup` becomes conceptually:

```text
Figure [SEQ Figure field, cached result 2]: Measurement setup
```

Only `2` is replaced. Its run formatting, surrounding label, punctuation and caption text remain. `replace_number` can handle digits split across runs and retains their formatting in the cached field result. It rejects unsupported nested or embedded run content instead of flattening it. A `lastRenderedPageBreak` cache marker may be discarded when reconstructing a touched run.

Each new caption number receives a bookmark named `QCaption_` plus 24 hexadecimal characters from a SHA-256 digest of its Quarto anchor, or a type/number fallback. This produces a short, valid, deterministic name. Numeric bookmark IDs are allocated beyond the current maximum, and duplicate names/anchors are rejected.

Quarto's original bookmark may span an image and its caption; it does not necessarily wrap the caption as an XML element. The code tracks active start/end ranges while traversing the document, allowing a caption in a layout table to be associated with its `fig-` or `tbl-` anchor.

A second pass finds internal hyperlinks to the processed anchors. If a link's displayed text ends with the target number, those final digits become `REF QCaption_...`, preserving the hyperlink and any label text. Processing references after all captions also handles forward references. Descriptive links, literal prose references, links without matching targets and links already containing fields are left alone.

Fields contain cached digits and `dirty=true`; Python does not run Word's field engine. Use Word's field update command to recalculate after Word edits and when building lists. Deleting a referenced caption in Word requires removing or redirecting references to it.

An already-finished document is not given duplicate `SEQ` fields. If there is nothing new to change, its bytes are left untouched. The returned caption counts include existing SEQ fields, while the REF count means newly converted links. The normal workflow still uses a fresh render on every build, rather than combining partially processed Word documents.

A complete `.fields-tmp` ZIP is staged and replaced atomically for this step. Styles, pictures, relationships and all other members pass through unchanged. Unsupported numbering discovered before staging leaves the input to this helper untouched.

### 5.11 `scripts/import-captions.lua`

Transforms the DOCX reader's caption structures into QMD that Quarto understands.

| Function / handler | Responsibility |
|---|---|
| `caption_blocks(blocks)` | Remove caption Div/Span containers while keeping their contents and other inline formatting. |
| `strip_label(blocks)` | Consume a leading English `Figure`/`Table` label and numeric prefix across text/space nodes so Quarto can number the caption later. |
| `new_figure(contents, caption, attr)` | Preserve or create a figure ID, split image-only multi-picture paragraphs, then append the caption inside a figure Div. |
| `only_images(block)` | Accept a nonempty image-only paragraph/plain block, allowing spaces and soft breaks. |
| `join_caption(blocks)` | Join a caption-styled paragraph beginning with `Figure` and a number to an immediately preceding image-only paragraph. |
| `Figure` handler | Convert a recognized captioned figure; unwrap an uncaptioned figure to its content. |
| `Table` handler | Assign an ID and normalize caption content when the imported table has a caption. |

The returned filter list runs two passes: native Figure/Table nodes first, adjacent image-plus-caption blocks second. Generated IDs use independent `fig-import-N` and `tbl-import-N` counters. These are anchors, not fixed display numbers; subsequent Quarto builds number the current document order.

The multi-picture paragraph split solves a second picture-loss case: even when all pictures survive DOCX import, Quarto's Word float renderer could retain only the first image in a shared paragraph. Separate image blocks preserve the pictures in a shared-caption figure.

This filter recognizes specific structures and English prefixes. It is not a universal recognizer for arbitrary manually formatted or localized captions. Inspect imported captions and use the README syntax when a caption was not recognized.

### 5.12 `scripts/clean-body-text.lua`

An import filter with a top-down `Div` handler. It unwraps a container only when `custom-style="Body Text"` is its sole meaningful attribute: no identifier, classes or additional attributes.

When it encounters another explicit style, it returns that Div with traversal disabled for the subtree. A nested Body Text block may be an intentional reset of inherited formatting and is therefore preserved. Removing a redundant wrapper returns its existing blocks in the same order; it does not flatten their content to text.

### 5.13 `scripts/table-borders.lua`

A Word-only filter that marks authored tables before Quarto builds layout tables. `tag_table(t)` finds the first available cell in the head, body or foot; an empty table with no cells is rejected. It removes `custom-style` from the table attribute list and transports its value in the XML comment marker consumed by `docx_tables.py`.

Quarto may have already moved a captioned table's attributes onto a `FloatRefTarget`. The first filter pass recovers that `custom-style` onto the first contained table and removes it from the float wrapper. The second pass tags every Table. Hex encoding makes style names safe inside XML comments, including names containing non-ASCII bytes or comment-sensitive punctuation.

The marker goes inside a cell so the Python finisher can identify the correct table even when it becomes nested in a generated layout table. It is invisible and removed before a successful Word build completes.

### 5.14 `scripts/docx-captions.lua`

A Word-only export filter. The local `caption(p)` function handles both `Para` and `Plain` nodes. It recognizes Quarto's raw OpenXML `ImageCaption` properties, removes raw paragraph-property fragments, and wraps the caption in a single named-style Div.

Caption text beginning with `Table` selects `Table Caption`; other recognized captions select `Image Caption`. This avoids duplicate `w:pPr` properties and assigns separate figure/table styles. It does not create the native sequence fields; `docx_fields.py` performs that later. The recognition relies on Quarto's generated markup and standard English labels.

### 5.15 `scripts/body-text.lua`

A Word-only export filter with a whole-document `Pandoc` handler. It examines only top-level `Para` blocks. If a paragraph contains no image or raw inline markup, it wraps that paragraph with the `Body Text` custom style in the export tree.

This prevents ordinary text after a heading from unexpectedly using Pandoc's `FirstParagraph` style. It deliberately does not recursively restyle explicit Divs, headings, lists, tables, figures or notes. The saved QMD stays uncluttered because the style wrapper is added only during export.

### 5.16 `scripts/check-document.lua`

The `Image(image)` handler checks resources at rendering time, after the Python preflight. HTTP/HTTPS/data URLs are skipped. Local URL escapes such as `%20` are decoded before opening the file in binary mode. A missing resource raises an error; a successful open is immediately closed and the image node is left unchanged.

In HTML this also checks the substituted preview path. The filter checks file accessibility, not image decoding or visual appearance. The build supplies it as a command-line filter after Quarto's core pass.

### 5.17 `scripts/html-images.lua`

An HTML-only `Image(el)` handler. It replaces a case-insensitive `.wmf` or `.emf` suffix with `-review.png` in the document tree. It does not create the preview; `prepare_images` must run first. It changes neither the QMD on disk nor the Word export's source paths.

Automatic preview generation searches only the project's `assets` directory. Keep legacy vector pictures there; a vector referenced elsewhere will not automatically receive a preview. The suffix substitution is intended for local file paths ending in the extension.

### 5.18 `styles/review.css`

Defines browser appearance: serif body text, a white paper-like content area, paragraph indentation, distinct heading levels, centered captions, responsive images, table cell borders and compact margins on small screens. It has no effect on Word styles or pagination.

The importer copies this master file into each project. Editing the master affects future imports; editing the project's `review.css` changes that project's subsequent HTML builds. The CSS is a shared review design, not an automatic translation of each source document's Word styles.

## 6. Generated project files

| Generated item | Ownership and lifecycle |
|---|---|
| `<name>.qmd` | Main editable source. Import creates it; builds read it. |
| `original.docx` | Unchanged source copy for comparison or recovery. Builds do not read it. |
| `reference.docx` | Style/page-setting reference. Users may edit its Word styles for future builds. |
| `_quarto.yml` | Per-project settings and computed filter paths; path refresh or an older table-filter upgrade may save a backup. |
| `review.css` | Editable project-specific HTML stylesheet. |
| `assets/` | Extracted and user-added pictures; keep it with the QMD. |
| `assets/**/*-review.png` | Generated legacy-vector previews; refreshed during HTML builds. |
| `output/` | Generated exports; each successful rebuild replaces the same output filename. |
| `.quarto/`, `__pycache__/` | Possible runtime/cache directories; not release source files. |

Projects may live anywhere, for example `repository/module/xxxx/design` beside `repository/module/xxxx/src`. Keep QMD, reference, assets, CSS and configuration together in the design folder. The old `toolkit/projects/<name>` location remains the default only when import omits `--project-dir`.

Filter paths are relative whenever both folders share a Windows drive, otherwise absolute. Before each Word/HTML render, toolkit-managed filter entries are rebound to the running installation if necessary. Moving or cloning a project therefore does not require hand-editing those paths when using the build command. Every computer still needs the toolkit and Quarto/Python installations; projects do not bundle copies of the runtime scripts.

## 7. Guarantees, checks and practical limits

The tool checks project-name collisions, local image availability, malformed caption tokens, renderer warnings, table-marker counts, supported caption sequences and minimum output picture counts. These checks address the reproduced conversion failures; they are not proof that every arbitrary Word feature was preserved.

Picture counts do not prove correct cropping, placement or identity. Reference styles do not reconstruct floating objects, text boxes, every section break, all direct formatting or exact pagination. Word and HTML still need review for the intended document layout.

Native fields support continuous Arabic Figure/Table numbering in the main document, including layout tables. They do not implement chapter prefixes, Roman/letter schemes, numbered subfigures, localized label rules, or caption fields in headers/footers/notes. Linked numeric cross-references depend on Quarto's hyperlink representation; manually typed numbers are not made dynamic automatically.

Each Word finisher uses a temporary ZIP and atomic replacement for its own step. **The entire build is not a transaction:** Quarto may already have produced output, and table finishing may already have succeeded before caption finishing reports an error. An import failure may also leave a partially created project. Correct errors and complete a successful build before distributing an output; preserve edited work before removing or retrying a partial project.

The toolkit writes field instructions and cached values; Microsoft Word calculates them when fields are updated. It does not automatically insert Word lists of figures/tables, and additions made only in Word are overwritten by a subsequent QMD build.

## 8. Maintenance and verification

Release 1.1.0 adds arbitrary import destinations, caller-relative project paths, destination-based default QMD naming, collision protection for existing folders and automatic rebinding of built-in filter paths. Document conversion filters, table/field finishing and CSS retain the behavior of 1.0.1.

When modifying the implementation, preserve these relationships:

1. Keep the table marker prefix/hex encoding synchronized between Lua and Python.
2. Preserve the filter order around `quarto` and the distinction between data and layout tables.
3. Keep caption style names consistent across reference preparation, caption styling and field detection.
4. Preserve matching `*-review.png` naming in Python and the HTML filter.
5. Test the batch launchers with paths containing spaces and verify that failures return a nonzero status.
6. Test import plus both exports on actual documents. For Word, inspect pictures, table borders, cached captions, `SEQ`/`REF` fields and updates in Word when field-generation behavior changes. For HTML, inspect embedded resources and content.

Development regression tests and test documents stay outside the release folder. They cover caption text/format preservation, existing fields, forward references, split numeric runs, unsupported numbering, nested/one-cell tables, explicit styles, filter upgrades, caller-relative resolution, cross-drive path fallback, quoted filter paths, custom configuration preservation and import collision protection. Integration checks also exercise external project imports, project/toolkit relocation, builds from the design directory and the legacy default destination. Release packaging should exclude projects, generated documents, caches and test outputs while including every runtime file and both guides.
